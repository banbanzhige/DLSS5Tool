# NVIDIA 消息服务令牌兼容修复

- 用户授权：2026-11-11「先修复修正我们自己工作进程与 NVIDIA 消息服务之间的令牌访问兼容性」；优先本源头修复及定向验收，中途续导搁置。
- 负责人：Codex；创建 2026-11-11；复核日期 2026-11-18。
- 输入：35849a5 及其固定证据；现有 `.venv`、Python 3.13.3 和 runtime 只读复用。
- 峰值预算：256 MiB；登记时 F 盘约 47 GiB 可用；不复制模型或开发环境。
- 范围：仅本产品新创建、启动门阻挡且已归属 Job 的 NR/VSR/GPU 工作进程主令牌；只在已确认的受限令牌 DACL 形态补充 LocalSystem READ_CONTROL，逐项核对其他 ACE 和父令牌不变；普通路径不修改；不改变令牌身份、组、特权、TokenDefaultDacl 或系统服务。
- 允许：修改本仓库；运行定向测试和 Job 限定的合成帧真实运行；公开官方文档核查；保存哈希及隔离设置。
- 重建：基础 Python -B，PYTHONPATH=.venv/Lib/site-packages，TEMP/TMP 指向本任务；pytest --basetemp=<本任务>/pytest -p no:cacheprovider；真实探针命令随脚本保存。
- 输出：可复用代码放 dlss5tool/、scripts/ 和 tests/；验收报告和必要证据放 docs/development/；仅提交本任务文件，不推送／打包／上传。
- 收尾：归档逐文件校验后清理本任务可重建产物，保留 TASK.md；旧目录和依赖不清理。

## 完成记录与重建

- 产品改动：`dlss5tool/nvidia_token_compat.py` 和既有 Job 入口；只识别实测中等完整性受限令牌三条允许 ACE 形态，为 LocalSystem 增加 READ_CONTROL；全程原启动门保护，父令牌／逻辑权限不变。
- 197 项定向测试及 5 个子测试通过；真实 Popen／spawn、冻结启动、令牌逻辑内容、原生 NR／VSR、压力恢复与更新器生命周期结果见证据。
- NR 关闭对照检查点新增 189,568 个 MessageBus 线程，启用后的 NR／VSR 五分钟窗口新增零且通过既定增长门槛；普通账户不修改权限，首帧哈希匹配历史基线。
- 明确边界：最小冻结夹具不是完整新发行包；本轮未重新跑三十分钟／整夜完整视频、原用户 32 GiB 或全部驱动。中途续导搁置，不自动推送或发版。
- 冻结重建：基础 Python 3.13.3，PYTHONPATH=.venv/Lib/site-packages，PYINSTALLER_CONFIG_DIR=<本任务>/pyinstaller-cache，TEMP/TMP=<本任务>；`python -B -m PyInstaller --noconfirm --log-level WARN --onedir --console --name TokenCompatFixture --paths F:/project/DLSS5Tool --exclude-module dlss5tool.cuda_session --exclude-module numpy --exclude-module cv2 --distpath <本任务>/frozen-dist --workpath <本任务>/frozen-build --specpath <本任务> <本任务>/frozen_token_fixture.py`；PyInstaller 6.22.2。
- `frozen-build/`、`frozen-dist/`、`pyinstaller-cache/` 为本任务可重建编译／标准库运行夹具，文件哈希清单保留，归档时不重复保存整套夹具二进制。
- 恢复位置：docs/development/nvidia-token-compat-20261111/observations.zip 及 archive-index.json；测量版本在 measured-sources/，最终版本在 final-sources/。
- 报告：docs/development/NVIDIA_TOKEN_COMPAT_FIX_20261111.md；清理、剩余字节及实际可用空间前后差见 archive-verification.json；仅保留本登记至 2026-11-18 复核。
