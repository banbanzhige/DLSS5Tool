"""Verify final source compatibility observations without extrapolating scope."""
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import zipfile

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
sys.path.insert(0,str(ROOT))
from scripts.compare_p0_stability import window_stats


def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def lines(path):return [json.loads(x) for x in path.read_text(encoding='utf-8-sig').splitlines()]


with zipfile.ZipFile(ROOT/'docs/development/nvmessagebus-cause-20261111/observations.zip') as old:
    baseline={kind:json.loads(old.read(name+'/worker-result.json'))['first_output_sha256']
        for kind,name in [('nr','native-nr-ordinary-nr'),('sr','native-sr-ordinary-vsr')]}
cases=[]
for path in sorted(TASK.glob('native-*')):
    if not (path/'result.json').is_file():continue
    result,worker=read(path/'result.json'),read(path/'worker-result.json')
    if not (path/'events.jsonl').is_file():continue
    events=lines(path/'events.jsonl')
    kind='nr' if result['case']=='native-nr' else 'sr' if result['case']=='native-sr' else None
    if kind is None:continue
    assert result['processing_and_exit_passed'] and not result['safety_error']
    assert not result['remaining_before_recovery'] and not result['recovery']
    assert read(path/'source-comparison.json')['unchanged']
    context,=result['native_execution_contexts']
    assert context['query_complete']
    identity=context['pid'],context['created_filetime']
    start=next(e['wall'] for e in events if e['event']=='idle-start')
    end=next(e['wall'] for e in events if e['event']=='idle-end')
    samples=read(path/'memory-samples.json')
    values=[(s['wall'],p['private_bytes']) for s in samples if start+10<=s['wall']<=end
            for p in s['processes'] if (p['pid'],p['created'])==identity and 'private_bytes' in p]
    stats=window_stats(values)
    profile=lines(path/(kind+'-frame-memory.jsonl'))
    def msg(row):return sum(g['started'] for g in row['thread_activity']['groups']
                           if 'NvMessageBus.dll' in g.get('module',''))
    off=path.name.endswith('control-off')
    ordinary='ordinary' in path.name
    assert context['token_restricted'] == (not ordinary)
    mask=context['primary_token_dacl']['explicit_system_allow_mask']
    assert mask == (0 if off else 0xf01ff if ordinary else 0x20000)
    assert worker['first_output_sha256']==baseline[kind]
    if off:assert msg(profile[-1])-msg(profile[0])>10000
    elif len(profile)>1:assert msg(profile[-1])-msg(profile[0])==0
    gate=(stats['sufficient_samples'] and stats['mib_per_minute']<=.25
          and abs(stats['delta_bytes'])<=16*1024**2)
    duration=result['run_arguments']['idle_seconds']
    if duration==300:assert gate
    before=read(path/'run-manifest-before.json')['files']
    measured={r['file']:r['sha256'] for r in read(TASK/'measured-source-manifest.json')}
    for name in ('dlss5tool/nvidia_token_compat.py','dlss5tool/process_job.py',
                 'scripts/verify_p0_stability.py','scripts/profile_native_frame_memory.py'):
        expected=next(r['sha256'] for r in before if r['file']==name)
        assert measured[name]==expected
    cases.append(dict(case=path.name,configured_idle_seconds=duration,frames=worker['frames'],
        elapsed_seconds=result['elapsed_seconds'],worker_context=context,private_window=stats,
        five_minute_gate_passed=gate if duration==300 else None,
        messagebus_total_observed=msg(profile[-1]),messagebus_checkpoint_delta=msg(profile[-1])-msg(profile[0]),
        profile_count=len(profile),profile_span_seconds=profile[-1]['wall']-profile[0]['wall'],
        source_runtime_unchanged=True,processing_and_exit_passed=True,first_output_matches_baseline=True,
        first_output_sha256=worker['first_output_sha256'],remaining=[],supervisor_recovery=[]))
assert len(cases)==6
tests=[]
for name in ('unit.xml','related.xml','recovery.xml'):
    suites=ET.parse(TASK/name).getroot().findall('testsuite')
    assert all(int(s.get(k,'0'))==0 for s in suites for k in ('errors','failures','skipped'))
    tests.append(dict(file=name,xml_cases=sum(int(s.get('tests')) for s in suites),passed=True))
assert sum(r['xml_cases'] for r in tests)==202 # 197 test items plus five subtests.
probes=[]
for name in ('token-sandbox.json','token-ordinary.json','frozen-sandbox.json','frozen-ordinary.json',
             'token-contents-sandbox.json','token-contents-ordinary.json'):
    record=read(TASK/name)
    assert record['status']=='passed'
    probes.append(dict(file=name,passed=True,cycles=len(record.get('cycles',record.get('rows',[])))))
protected=read(TASK/'protected-user-file-hashes.json')
assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest for name,digest in protected.items())
summary=dict(scope='Worker-token source compatibility fix, not all original user/P0 scenarios.',
    native_cases=cases,test_items_passed=197,subtests_passed=5,tests=tests,token_probes=probes,
    protected_user_files_unchanged=True,all_five_minute_fixed_windows_passed=True,
    product_entry_points=['NR','legacy VSR','resident GPU export','resident GPU preview','parallel export'],
    frozen_scope='Minimal real PyInstaller onedir fixture, not a rebuilt product release.',
    limitations=['One GPU/621.14 driver and small synthetic native inputs.',
        'Post-fix five-minute idle and short processing; no new thirty-minute or overnight product validation.',
        'Token compatibility only matches the observed restricted medium-integrity allow-only ACL shape.',
        'Driver 184-byte-per-thread retention itself remains an upstream issue.'])
recovery=read(TASK/'recovery-fixed-verification.json')
assert recovery['passed'] and recovery['source_and_runtime_unchanged']
assert not recovery['remaining_before_supervisor_cleanup'] and recovery['error'] is None
details=read(TASK/'recovery-fixed/result.json')
assert {r['kind'] for r in details}=={'nr','vsr'}
for row in details:
    assert row['passed'] and row['queue_states']==['completed']*3 and row['completed_output_unchanged']
    assert len(row['attempts'])==2 and row['attempts'][0]['pid']!=row['attempts'][1]['pid']
    assert row['attempts'][0]['output_sha256']==row['attempts'][1]['output_sha256']
summary['real_pressure_recovery']=dict(verification=recovery,details=details)
lifetime=read(TASK/'updater-lifetime/result.json')
assert lifetime['workload_exit']==0 and not lifetime['cleanup'] and not lifetime['final']
assert lifetime['cycles']==1 and lifetime['app_exit_observation_seconds']==20
summary['real_updater_lifetime']=dict(workload_exit=0,cycles=1,peak_owned=lifetime['peak_owned'],
    final=lifetime['final'],cleanup=lifetime['cleanup'],app_exit_observation_seconds=20)
smoke=read(TASK/'native-idle-manifest-off-smoke/result.json')
assert smoke['processing_and_exit_passed'] and not smoke['recovery'] and not smoke['safety_error']
manifest=read(TASK/'native-idle-manifest-off-smoke/run-manifest-before.json')
assert manifest['diagnostic_environment']['DLSS5TOOL_NVIDIA_TOKEN_COMPAT']=='off'
assert read(TASK/'native-idle-manifest-off-smoke/source-comparison.json')['unchanged']
summary['final_manifest_smoke_passed']=True
(TASK/'verification.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps([dict(case=r['case'],delta_mib=r['private_window']['delta_bytes']/1024**2,
    mib_per_minute=r['private_window']['mib_per_minute'],messagebus_delta=r['messagebus_checkpoint_delta'],
    five_minute_gate=r['five_minute_gate_passed']) for r in cases],indent=2))
