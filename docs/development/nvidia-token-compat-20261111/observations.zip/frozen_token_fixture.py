"""Minimal frozen startup check; only own gated child tokens are inspected."""
import argparse
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import subprocess
import sys

from dlss5tool import nvidia_token_compat as compat
from dlss5tool.process_job import KillOnCloseJob


def main():
    api = compat._Windows()
    own = api.open_token(api.k.GetCurrentProcess(), 0x20008)
    try:
        if sys.argv[1:] == ['--child']:
            if sys.stdin.buffer.read(1) != b'G': raise SystemExit(2)
            print(json.dumps(dict(pid=os.getpid(), state=api.state(own),
                frozen=bool(getattr(sys,'frozen',False)), dacl_sha256=hashlib.sha256(api.dacl(own)).hexdigest())),flush=True)
            return
        parser=argparse.ArgumentParser()
        parser.add_argument('--output',type=Path,required=True)
        parser.add_argument('--expect',choices=('applied','unchanged'),required=True)
        args=parser.parse_args()
        assert getattr(sys,'frozen',False)
        state,original=api.state(own),api.dacl(own)
        rows=[]
        for index in range(3):
            child=subprocess.Popen([sys.executable,'--child'],stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
            job=None
            try:
                job=KillOnCloseJob(child,nvidia_compat=True)
                out,err=child.communicate(b'G',timeout=30)
                assert child.returncode==0,err.decode(errors='replace')
                row=json.loads(out)
                assert row['frozen'] and row['pid']==child.pid
                assert row['state']['id']!=state['id']
                assert job.token_compatibility['status']==args.expect,job.token_compatibility
                assert api.state(own)==state and api.dacl(own)==original
                rows.append(dict(child=row,compatibility=job.token_compatibility))
            finally:
                if job:job.close()
                child.wait(timeout=10)
                for stream in (child.stdin,child.stdout,child.stderr):
                    if stream:stream.close()
        assert not args.output.exists()
        args.output.write_text(json.dumps(dict(status='passed',frozen=True,rows=rows,
            parent_token_unchanged=True,all_children_exited=True),indent=2)+'\n',encoding='utf-8')
        print(json.dumps(dict(status='passed',frozen=True,expect=args.expect,cycles=len(rows))))
    finally:
        api.close(own)


if __name__=='__main__':
    multiprocessing.freeze_support()
    main()
