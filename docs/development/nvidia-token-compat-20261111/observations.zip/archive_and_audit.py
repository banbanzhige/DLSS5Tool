"""Archive owned evidence; omit reproducible freezer build trees; never delete."""
import ast
import ctypes as C
import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import zipfile

TASK=Path(__file__).absolute().parent
ROOT=TASK.parents[1]
DEST=ROOT/'docs/development/nvidia-token-compat-20261111'
sys.path.insert(0,str(ROOT))
from scripts.ngx_updater_lifecycle_probe import Processes


def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def save(path,data):path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


def checked(path):
    path=path.absolute()
    for part in [path,*path.parents]:
        if part.exists() and part.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise ValueError('Reparse point rejected: '+str(part))
    assert path.resolve()==path
    return path


checked(TASK);checked(DEST)
assert TASK==ROOT/'tmp/nvidia-token-compat-20261111' and (TASK/'TASK.md').is_file()
assert not DEST.exists()
free_before=shutil.disk_usage(ROOT).free
assert free_before>15*1024**3+256*1024**2
protected=read(TASK/'protected-user-file-hashes.json')
assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest for name,digest in protected.items())
names=[r['file'] for r in read(TASK/'measured-source-manifest.json')]
final=TASK/'final-sources'
manifest=[]
for name in names:
    data=checked(ROOT/name).read_bytes()
    if name.endswith('.py'):ast.parse(data,filename=name)
    target=checked(final/name)
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    manifest.append(dict(file=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
save(TASK/'final-source-manifest.json',manifest)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True,capture_output=True)

identities=set()
for path in TASK.glob('native-*/result.json'):
    for row in read(path).get('observed_processes',[]):
        if row.get('created'):identities.add((row['pid'],row['created']))
for path in TASK.glob('token-*.json'):
    for row in read(path).get('cycles',[]):
        row=row['context']
        identities.add((row['pid'],row['created_filetime']))
for sample in read(TASK/'recovery-fixed-samples.json'):
    for row in sample['processes']:
        if row.get('created'):identities.add((row['pid'],row['created']))
for row in read(TASK/'updater-lifetime/result.json')['observed']:
    if row.get('owned') and row.get('created'):identities.add((row['pid'],row['created']))
processes=Processes();active=[];unknown=[];reused=[]
for row in processes.snapshot():
    if row['pid'] not in {p for p,_ in identities}:continue
    actual=processes.identity(row)
    if not actual.get('created'):unknown.append(actual)
    elif (actual['pid'],actual['created']) in identities:active.append(actual)
    else:reused.append(actual)
assert not active and not unknown,(active,unknown)

omitted_roots={'frozen-build','frozen-dist','pyinstaller-cache'}
all_files=[]
for path in TASK.rglob('*'):
    checked(path)
    if path.is_file():all_files.append(path)
omitted=[]
for path in all_files:
    name=path.relative_to(TASK).as_posix()
    if name.split('/')[0] in omitted_roots:
        omitted.append(dict(file=name,bytes=path.stat().st_size,
            sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
save(TASK/'freezer-artifact-manifest.json',dict(files=omitted,
    rebuild='PyInstaller 6.22.2; frozen_token_fixture.py and TokenCompatFixture.spec; exact options in TASK.md.',
    reason='Reproducible stdlib fixture binaries/build intermediates; no need to commit a duplicate Python runtime.'))

kernel=C.WinDLL('kernel32',use_last_error=True)
kernel.CreateFileW.argtypes=[C.c_wchar_p,C.c_uint32,C.c_uint32,C.c_void_p,C.c_uint32,C.c_uint32,C.c_void_p]
kernel.CreateFileW.restype=C.c_void_p
kernel.CloseHandle.argtypes=[C.c_void_p]
for path in all_files:
    handle=kernel.CreateFileW(str(path),0x80000000,0,None,3,0x80,None)
    if handle==C.c_void_p(-1).value:raise C.WinError(C.get_last_error())
    kernel.CloseHandle(handle)
save(TASK/'final-audit.json',dict(python_ast_passed=True,git_diff_check_passed=True,
    protected_user_files_unchanged=True,audited_process_identities=[dict(pid=p,created=c) for p,c in sorted(identities)],
    active_owned_processes=active,unverified_processes=unknown,reused_process_ids=reused,
    exclusive_open_existing_task_files_passed=True,final_source_manifest=manifest))

DEST.mkdir()
files=sorted(p for p in TASK.rglob('*') if p.is_file() and p.relative_to(TASK).parts[0] not in omitted_roots)
index=[]
with zipfile.ZipFile(DEST/'observations.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in files:
        data=path.read_bytes();name=path.relative_to(TASK).as_posix()
        index.append(dict(file=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        archive.writestr(name,data)
with zipfile.ZipFile(DEST/'observations.zip') as archive:
    assert archive.testzip() is None
    assert archive.namelist()==[r['file'] for r in index]
    for row in index:
        data=archive.read(row['file'])
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
        assert (TASK/row['file']).read_bytes()==data
save(DEST/'archive-index.json',index)
for name in ('verification.json','final-audit.json','final-source-manifest.json'):
    (DEST/name).write_bytes((TASK/name).read_bytes())
archive=DEST/'observations.zip'
save(DEST/'archive-verification.json',dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    archive_bytes=archive.stat().st_size,entries=len(index),uncompressed_bytes=sum(r['bytes'] for r in index),
    all_entry_sha256_and_lengths_verified=True,source_bytes_equal=True,reparse_checks_passed=True,
    exclusive_open_files_passed=True,known_process_identity_count=len(identities),active_owned_processes=[],
    omitted_rebuildable_files=omitted,omitted_roots=sorted(omitted_roots),
    free_bytes_before_archive=free_before,free_bytes_after_archive=shutil.disk_usage(ROOT).free,
    cleanup_completed=False,cleanup_plan=[dict(path=str(checked(p)),directory=p.is_dir())
        for p in sorted(TASK.iterdir()) if p.name!='TASK.md'],review_date='2026-11-18'))
print(json.dumps(dict(archive_entries=len(index),archive_bytes=archive.stat().st_size,
    omitted_files=len(omitted),known_process_identities_retired=len(identities),source_ast_passed=True)))
