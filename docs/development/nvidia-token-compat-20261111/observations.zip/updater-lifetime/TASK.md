本次 nvidia-token-compat-20261111 的更新器生命周期关联验收；归属、预算和恢复见父目录 TASK.md。
