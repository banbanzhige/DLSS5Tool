"""Verify ACL compatibility does not change logical token security contents."""
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from dlss5tool.nvidia_token_compat import _Windows, prepare_worker_token
from dlss5tool.process_job import KillOnCloseJob


class Group(C.Structure):
    _fields_=[('sid',C.c_void_p),('attributes',C.c_uint32)]


class Groups(C.Structure):
    _fields_=[('count',C.c_uint32),('groups',Group*1)]


def contents(api,token):
    def sid(pointer):
        return hashlib.sha256(C.string_at(pointer,api.a.GetLengthSid(pointer))).hexdigest()
    result={}
    for key,kind in [('user',1),('owner',4),('primary_group',5)]:
        value=api.info(token,kind)
        result[key]=sid(C.cast(value,C.POINTER(C.c_void_p))[0])
    for key,kind in [('groups',2),('restricting_sids',11)]:
        value=api.info(token,kind)
        count=C.c_uint32.from_buffer(value).value
        assert count<16384
        result[key]=[(sid(row.sid),row.attributes) for row in
            (Group*count).from_buffer(value,Groups.groups.offset)]
    value=api.info(token,3)
    count=C.c_uint32.from_buffer(value).value
    result['privileges']=[struct.unpack_from('<QI',value,4+index*12) for index in range(count)]
    value=api.info(token,6)
    default=C.cast(value,C.POINTER(C.c_void_p))[0]
    result['default_dacl']=None if not default else hashlib.sha256(
        C.string_at(default,C.c_ushort.from_address(default+2).value)).hexdigest()
    result['state']=api.state(token)
    return result


if __name__=='__main__':
    api=_Windows()
    parent=api.open_token(api.k.GetCurrentProcess(),0x20008)
    parent_before=contents(api,parent)
    parent_acl=api.dacl(parent)
    rows=[]
    try:
        for index in range(3):
            child=subprocess.Popen([sys.executable,'-B','-c',"import sys; sys.stdin.buffer.read(1)"],
                stdin=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
            job=KillOnCloseJob(child)
            token=api.open_token(int(child._handle),0x20008)
            try:
                before=contents(api,token)
                acl_before=api.dacl(token)
                result=prepare_worker_token(int(child._handle))
                assert result['status']==sys.argv[1],result
                after=contents(api,token)
                assert before==after
                assert contents(api,parent)==parent_before and api.dacl(parent)==parent_acl
                child.communicate(b'G',timeout=20)
                assert child.returncode==0
                rows.append(dict(pid=child.pid,token_contents_unchanged=True,parent_unchanged=True,
                    token_contents_sha256=hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),
                    acl_changed=api.dacl(token)!=acl_before,compatibility=result))
            finally:
                api.close(token)
                job.close()
                child.wait(timeout=10)
                if child.stdin:child.stdin.close()
        Path(sys.argv[2]).write_text(json.dumps(dict(status='passed',rows=rows,
            fields=['user','owner','primary_group','groups','restricting_sids','privileges','default_dacl','state']),
            indent=2)+'\n',encoding='utf-8')
        print(json.dumps(dict(status='passed',cycles=len(rows),token_contents_unchanged=True)))
    finally:
        api.close(parent)
