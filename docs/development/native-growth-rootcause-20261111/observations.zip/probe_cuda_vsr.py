"""Check whether the existing CUDA VSR route actually avoids driver residency."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
TASK = Path(__file__).resolve().parent
WORK = TASK / 'cuda-vsr-route'

def save(path, value):
    path.write_text(json.dumps(value, indent=2, default=str) + '\n')

def worker():
    if sys.stdin.buffer.read(1) != b'G':
        raise RuntimeError('Missing owned-job startup gate')
    os.environ.update(TEMP=str(WORK), TMP=str(WORK), DLSS5TOOL_DISABLE_UPDATE_CHECK='1',
                      DLSS5TOOL_P0_HEAP_TRACE='0')
    from dlss5tool import paths
    state = WORK / 'state'
    state.mkdir()
    paths.state_path = lambda name: state / name
    import numpy as np
    from dlss5tool.cuda_session import CudaSession
    from dlss5tool.cuda_frame import CudaImage, FrameTiming
    from dlss5tool.cuda_vsr import CudaVSR
    from scripts.profile_native_frame_memory import Profile
    session = CudaSession()
    image = CudaImage(session, 320, 180)
    backend = CudaVSR.from_runtime(session, 320, 180, 2, log_path=WORK / 'cuda-vsr.log')
    pixels = np.zeros((180, 320, 4), dtype=np.uint8)
    pixels[..., 3] = 255
    hashes = []
    for number in range(3):
        with image.upload(pixels, FrameTiming(number)) as source:
            with backend.process_device(source) as output:
                result = backend._output.download(output)
                assert result.shape == (360, 640, 4)
                hashes.append(hashlib.sha256(result.tobytes()).hexdigest())
    profile = Profile('cuda-vsr')
    started = time.time()
    save(WORK / 'idle-start.json', dict(wall=started, pid=os.getpid(), hashes=hashes,
                                       route='existing verified CudaVSR, highest quality, SDR 2x'))
    profile.record(force=True)
    for _ in range(3):
        time.sleep(20)
        profile.record(force=True)
    save(WORK / 'idle-end.json', dict(wall=time.time()))
    backend.close()
    image.close()
    session.close()
    save(WORK / 'worker-result.json', dict(status='passed', frames=3, hashes=hashes, closed=True))

def supervise():
    from dlss5tool.memory_budget import system_memory
    from dlss5tool.process_job import KillOnCloseJob
    from scripts.ngx_updater_lifecycle_probe import Processes
    from scripts.verify_p0_stability import Memory, checked_path
    from scripts.verify_native_worker_recycling import job_pids
    checked_path(WORK)
    WORK.mkdir(exist_ok=False)
    child = job = None
    record = dict(processing_and_exit_passed=False, gpu_queries=False, samples=[])
    began = time.monotonic()
    try:
        with (WORK / 'console.log').open('wb') as output:
            child = subprocess.Popen([sys.executable, '-B', str(Path(__file__).resolve()), '--worker'],
                stdin=subprocess.PIPE, stdout=output, stderr=subprocess.STDOUT, cwd=ROOT,
                creationflags=subprocess.CREATE_NO_WINDOW)
            job = KillOnCloseJob(child)
            processes = Processes()
            memory = Memory(processes)
            row, = [r for r in processes.snapshot() if r['pid'] == child.pid]
            identity = processes.identity(row)
            assert identity.get('created')
            record['identity'] = identity
            child.stdin.write(b'G')
            child.stdin.close()
            while child.poll() is None:
                status = system_memory()
                sample = dict(wall=time.time(), seconds=time.monotonic() - began,
                              memory=memory.read(identity), system=status)
                record['samples'].append(sample)
                if (sample['seconds'] > 120 or sample['memory'].get('private_bytes', 0) > 2 * 1024**3
                        or not status or min(status['free_commit_bytes'], status['free_physical_bytes']) < 8 * 1024**3):
                    raise RuntimeError('Diagnostic time/private/headroom limit')
                time.sleep(.25)
            child.wait(timeout=10)
            record['remaining_before_cleanup'] = job_pids(job)
            assert child.returncode == 0 and record['remaining_before_cleanup'] == []
        record['processing_and_exit_passed'] = True
    except BaseException:
        record['error'] = traceback.format_exc()
    finally:
        if child and child.stdin and not child.stdin.closed:
            child.stdin.close()
        if job:
            job.close()
        if child:
            if child.poll() is None:
                child.terminate()
            child.wait(timeout=10)
            record['returncode'] = child.returncode
        record['elapsed_seconds'] = time.monotonic() - began
        save(WORK / 'verification.json', record)
    print(json.dumps({k:v for k,v in record.items() if k != 'samples'}), flush=True)
    return 0 if record['processing_and_exit_passed'] else 1

if __name__ == '__main__':
    if '--worker' in sys.argv:
        worker()
    else:
        raise SystemExit(supervise())
