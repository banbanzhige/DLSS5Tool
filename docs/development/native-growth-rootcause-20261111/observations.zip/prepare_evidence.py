"""Archive only this task's owned, finished diagnostics; no installed DLL copies."""
import ast
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts.verify_p0_stability import checked_path
from scripts.ngx_updater_lifecycle_probe import Processes

TASK = checked_path(Path(__file__).resolve().parent)
OUT = checked_path(ROOT / 'docs/development/native-growth-rootcause-20261111')
assert TASK == ROOT / 'tmp/native-growth-rootcause-20261111' and (TASK / 'TASK.md').is_file()
OUT.mkdir(exist_ok=False)

def save(path, value):
    path.write_text(json.dumps(value, indent=2, default=str) + '\n', encoding='utf-8')

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

sources = ['scripts/verify_p0_stability.py', 'scripts/verify_native_driver_threads.py',
    'scripts/native_driver_thread_probe.cpp', 'scripts/native_heap_trace.cpp', 'scripts/native_thread_activity.cpp',
    'scripts/profile_native_frame_memory.py', 'scripts/profile_thread_activity.py',
    'scripts/inspect_native_allocations.py', 'scripts/summarize_native_heap_trace.py',
    'scripts/verify_native_worker_recycling.py', 'scripts/ngx_updater_lifecycle_probe.py',
    'dlss5tool/process_job.py', 'dlss5tool/cuda_session.py', 'dlss5tool/cuda_frame.py',
    'dlss5tool/cuda_vsr.py', 'dlss5tool/cuda_vsr_runtime.py', 'native/vsr_cuda/vsr_cuda.cpp']
snapshots = checked_path(TASK / 'measured-sources')
snapshots.mkdir()
source_index = []
for name in sources:
    source = checked_path(ROOT / name)
    target = checked_path(snapshots / name.replace('/', '__'))
    target.write_bytes(source.read_bytes())
    if name.endswith('.py'):
        ast.parse(target.read_text(encoding='utf-8'))
    source_index.append(dict(source=name, snapshot=str(target.relative_to(TASK)), sha256=digest(target)))
save(TASK / 'source-index.json', source_index)

summary = json.loads((TASK / 'verification.json').read_text())
identities = {}
for directory in TASK.iterdir():
    if not directory.is_dir():
        continue
    for name in ('result.json', 'verification.json'):
        path = directory / name
        if not path.is_file():
            continue
        value = json.loads(path.read_text())
        for row in [value.get('identity', {})] + value.get('observed_processes', []):
            if row.get('pid') and row.get('created'):
                identities[(row['pid'], row['created'])] = row
processes = Processes()
live = []
for row in processes.snapshot():
    if any(pid == row['pid'] for pid, _ in identities):
        identity = processes.identity(row)
        if (identity.get('pid'), identity.get('created')) in identities:
            live.append(identity)
assert not live, live

vsr = json.loads((TASK / 'cuda-vsr-route/verification.json').read_text())
assert vsr['processing_and_exit_passed'] is False
regions = [json.loads(s) for s in (TASK / 'cuda-vsr-route/cuda-vsr-frame-memory-regions.jsonl').read_text().splitlines()]
profiles = [json.loads(s) for s in (TASK / 'cuda-vsr-route/cuda-vsr-frame-memory.jsonl').read_text().splitlines()]
summary['cuda_vsr_exploration'] = dict(processing_and_exit_passed=False,
    supervisor_error=vsr['error'], returncode_after_job_cleanup=vsr['returncode'],
    elapsed_seconds=vsr['elapsed_seconds'],
    default_heap_allocated_delta=regions[-1]['default_heap']['allocated'] - regions[0]['default_heap']['allocated'],
    profile_span_seconds=profiles[-1]['wall'] - profiles[0]['wall'],
    thread_starts_delta=profiles[-1]['thread_activity']['started'] - profiles[0]['thread_activity']['started'],
    absent_in_module_snapshot='nvwgf2umx.dll',
    limitations='Three real SDR 2x frames then idle; native close timed out and Job recovery was required. '
                'Exit code after cleanup is not an application success. No close-blocking stack was captured.')
summary['retirement_audit'] = dict(exact_identities=len(identities), still_live=live)
save(TASK / 'verification.json', summary)

# Open without sharing: every task file must be quiescent before archiving.
kernel = C.WinDLL('kernel32', use_last_error=True)
kernel.CreateFileW.argtypes = [C.c_wchar_p, C.c_uint32, C.c_uint32, C.c_void_p, C.c_uint32, C.c_uint32, C.c_void_p]
kernel.CreateFileW.restype = C.c_void_p
kernel.CloseHandle.argtypes = [C.c_void_p]
files = []
for path in sorted(TASK.rglob('*')):
    checked_path(path)
    if not path.is_file():
        continue
    handle = kernel.CreateFileW(str(path), 0x80000000, 0, None, 3, 0x80, None)
    if handle == C.c_void_p(-1).value:
        raise C.WinError(C.get_last_error())
    kernel.CloseHandle(handle)
    files.append(path)
archive = checked_path(OUT / 'observations.zip')
index = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
    for path in files:
        relative = path.relative_to(TASK).as_posix()
        zipped.write(path, relative)
        index.append(dict(path=relative, bytes=path.stat().st_size, sha256=digest(path)))
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    assert len(zipped.namelist()) == len(index)
    for row in index:
        data = zipped.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
save(OUT / 'archive-index.json', index)
save(OUT / 'verification.json', summary)
(OUT / 'installed-module-metadata.json').write_bytes((TASK / 'installed-module-metadata.json').read_bytes())
record = dict(archive='observations.zip', archive_sha256=digest(archive),
    verified_entries=len(index), uncompressed_bytes=sum(r['bytes'] for r in index),
    compressed_bytes=archive.stat().st_size, exact_identities_checked=len(identities),
    observed_still_live=live, exclusive_file_opens=len(files),
    cleanup_pending=True, source_snapshots=len(source_index), python_syntax_checked=True,
    no_installed_driver_copies=True, no_long_term_plateau_claim=True)
save(OUT / 'archive-verification.json', record)
print(json.dumps(record, indent=2))
