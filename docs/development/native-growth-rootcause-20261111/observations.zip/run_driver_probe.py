"""Task-local supervisor; does not query the GPU or change installed modules."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from dlss5tool.memory_budget import system_memory
from dlss5tool.process_job import KillOnCloseJob
from scripts.ngx_updater_lifecycle_probe import Processes
from scripts.verify_p0_stability import Memory, checked_path
from scripts.verify_native_worker_recycling import job_pids

TASK = checked_path(Path(__file__).resolve().parent)
assert TASK.parent == ROOT / 'tmp' and (TASK / 'TASK.md').is_file()
exe = checked_path(TASK / 'build/native_driver_thread_probe.exe')
trace = checked_path(TASK / 'native_heap_trace.dll')
modules = json.loads((TASK / 'native-device11-cuda-d3d11/native-modules.json').read_text())
driver, = [checked_path(path) for path in modules if Path(path).name.lower() == 'nvwgf2umx.dll']
control = checked_path(Path(os.environ['SystemRoot']) / 'System32/version.dll')
processes = Processes()
memory = Memory(processes)

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

results = []
for name, target in [('system-control', control), ('nvidia-driver', driver)]:
    work = checked_path(TASK / ('thread-probe-' + name))
    work.mkdir(exist_ok=False)
    command = [str(exe), str(target), '30000', str(trace), str(work / 'heap')]
    record = dict(name=name, target=str(target), target_sha256=digest(target),
                  exe_sha256=digest(exe), trace_sha256=digest(trace), command=command,
                  gpu_queries=False, requested_threads=30000)
    samples = []
    began = time.monotonic()
    environment = dict(os.environ, TEMP=str(work), TMP=str(work))
    failure = None
    with (work / 'console.jsonl').open('wb') as output:
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=output,
            stderr=subprocess.STDOUT, cwd=work, env=environment,
            creationflags=subprocess.CREATE_NO_WINDOW)
        job = None
        try:
            job = KillOnCloseJob(child)
            row, = [r for r in processes.snapshot() if r['pid'] == child.pid]
            identity = processes.identity(row)
            assert identity.get('created')
            record['identity'] = identity
            child.stdin.write(b'G')
            child.stdin.close()
            while child.poll() is None:
                status = system_memory()
                sample = dict(seconds=time.monotonic() - began, memory=memory.read(identity), system=status)
                samples.append(sample)
                if (sample['seconds'] > 120 or sample['memory'].get('private_bytes', 0) > 1024**3
                        or not status or min(status['free_commit_bytes'], status['free_physical_bytes']) < 8 * 1024**3):
                    failure = 'Diagnostic time/private/headroom limit'
                    break
                time.sleep(.25)
            if failure:
                job.close()
            child.wait(timeout=10)
            deadline = time.monotonic() + 10
            while job._handle and job_pids(job) and time.monotonic() < deadline:
                time.sleep(.1)
            record['remaining_before_cleanup'] = job_pids(job) if job._handle else None
            record['returncode'] = child.returncode
        finally:
            if job:
                job.close()
            if child.poll() is None:
                child.wait(timeout=10)
            record.update(safety_error=failure, elapsed_seconds=time.monotonic() - began, samples=samples)
            (work / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    assert child.returncode == 0 and not failure and record['remaining_before_cleanup'] == [], record
    rows = [json.loads(line) for line in (work / 'console.jsonl').read_text().splitlines()]
    outcome = rows[-1]
    assert outcome['kind'] == 'result' and outcome['error'] == 0
    assert outcome['completed'] == 30000 and outcome['restored'] == outcome['patches']
    record['native_result'] = outcome
    (work / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    results.append(dict(name=name, **outcome))
    print(json.dumps(results[-1]), flush=True)
(TASK / 'thread-probe-summary.json').write_text(json.dumps(results, indent=2) + '\n')
