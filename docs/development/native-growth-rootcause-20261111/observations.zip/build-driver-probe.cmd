@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b %errorlevel%
cl /nologo /std:c++17 /O2 /Ob0 /MT /EHsc /Fe:native_driver_thread_probe.exe /Fo:native_driver_thread_probe.obj "F:\project\DLSS5Tool\scripts\native_driver_thread_probe.cpp" /link psapi.lib
exit /b %errorlevel%
