import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts.summarize_native_heap_trace import heap_trace, memory_map

task = Path(__file__).resolve().parent
matrix = []
for directory in sorted(task.glob('native-*')):
    if not directory.is_dir() or not (directory / 'result.json').is_file():
        continue
    result = json.loads((directory / 'result.json').read_text())
    events = [json.loads(s) for s in (directory / 'events.jsonl').read_text().splitlines()]
    pid = next(e['pid'] for e in events if e['event'] == 'starting')
    begin = next(e['wall'] for e in events if e['event'] == 'idle-start')
    end = next(e['wall'] for e in events if e['event'] == 'idle-end')
    samples = json.loads((directory / 'memory-samples.json').read_text())
    owned = [dict(wall=s['wall'], **p) for s in samples for p in s['processes']
             if p['pid'] == pid and begin + 10 <= s['wall'] <= end and 'private_bytes' in p]
    assert len({(s['pid'], s['created']) for s in owned}) == 1
    count = max(1, len(owned) // 5)
    delta = statistics.median(s['private_bytes'] for s in owned[-count:]) - statistics.median(s['private_bytes'] for s in owned[:count])
    span = statistics.median(s['wall'] for s in owned[-count:]) - statistics.median(s['wall'] for s in owned[:count])
    profile_path, = directory.glob('*-frame-memory.jsonl')
    profiles = [json.loads(s) for s in profile_path.read_text().splitlines()]
    first, last = profiles[0], profiles[-1]
    groups = []
    before = {g['start_address']: g['started'] for g in first['thread_activity']['groups']}
    for group in last['thread_activity']['groups']:
        groups.append(dict(module=group.get('module'), offset=hex(group.get('offset', 0)),
                           started_delta=group['started'] - before.get(group['start_address'], 0)))
    maps = memory_map(directory)
    trace_paths = sorted(directory.glob('native-heap-*.jsonl'))
    traces = [heap_trace(p) for p in trace_paths]
    native_modules = json.loads((directory / 'native-modules.json').read_text())
    modules = {name: [p for p in native_modules if Path(p).name.lower() == name.lower()]
               for name in ('nvcuda.dll', 'nvcuda64.dll', 'NvMessageBus.dll', 'nvwgf2umx.dll', 'nvdiagclt64.dll')}
    source_check = json.loads((directory / 'source-comparison.json').read_text())
    matrix.append(dict(case=directory.name, pid=pid, created=owned[0]['created'],
        processing_and_exit_passed=result['processing_and_exit_passed'],
        source_runtime_unchanged=source_check['unchanged'], gpu_snapshots_enabled=result['gpu_snapshots_enabled'],
        remaining_before_recovery=result['remaining_before_recovery'], safety_error=result['safety_error'],
        worker_private_mib_per_minute=delta / span * 60 / 1024**2,
        worker_private_window_delta=delta, measured_window_seconds=span,
        default_heap_allocated_delta=maps['heap_allocated_delta'], default_heap_span=maps['measured_span_seconds'],
        thread_starts_delta=last['thread_activity']['started'] - first['thread_activity']['started'],
        thread_stops_delta=last['thread_activity']['detached'] - first['thread_activity']['detached'],
        unclassified_threads=last['thread_activity']['unclassified'], thread_groups=groups,
        modules=modules, heap_traces=traces, long_term_memory_plateau_verified=False))

paired = []
for directory in sorted(task.glob('driver-threads-paired-*')):
    record = json.loads((directory / 'verification.json').read_text())
    lines = [json.loads(s) for s in (directory / 'console.jsonl').read_text().splitlines()]
    samples = [s for s in lines if s['kind'] == 'sample']
    first = next(s for s in samples if s['threads_completed'] == 10000)
    last = samples[-1]
    native_count = last['threads_completed'] - first['threads_completed']
    heap_delta = last['heap_allocated'] - first['heap_allocated']
    trace = heap_trace(directory / 'heap-after.jsonl') if record['trace_enabled'] else None
    paired.append(dict(case=directory.name, processing_and_exit_passed=record['processing_and_exit_passed'],
        source_unchanged=record['source_unchanged'], target_unchanged=record['target_unchanged'],
        identity=record['identity'], trace_enabled=record['trace_enabled'],
        threads_after_warmup=native_count, heap_allocated_delta_after_warmup=heap_delta,
        heap_bytes_per_thread=heap_delta / native_count,
        private_delta_after_warmup=last['private_bytes'] - first['private_bytes'],
        native_result=record['native_result'], heap_trace=trace,
        remaining_before_cleanup=record['remaining_before_cleanup']))

summary = dict(matrix=matrix, paired_driver_probes=paired,
    limitations=['One 60-second run per matrix condition; no long-term plateau certification.',
                 'Metadata/Python profiling adds a small baseline; thread rates are instrumentation-dependent.',
                 'Combined Python heap trace saturated stack capacity; use it for path matching only.',
                 'Standalone traced controls had no dropped objects/stacks; independent untraced HeapSummary confirms retention.',
                 'No official NVIDIA private symbols; addresses are verified module-relative offsets.',
                 'Does not isolate why NvMessageBus creates threads or prove all NR/VSR growth has one cause.'],
    operational_notes=['An initial compile command failed to start because its cwd did not yet exist; no build/test ran.',
        'The existing summarize_native_heap_trace.py top-level helper rejected mixed result schemas. '
        'This summary calls its per-case memory_map/heap_trace helpers only on matching case directories.'])
(task / 'verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(dict(matrix=[dict(case=r['case'], worker_private_mib_per_minute=r['worker_private_mib_per_minute'],
    heap_delta_mib=r['default_heap_allocated_delta'] / 1024**2,
    threads=r['thread_starts_delta'], groups=r['thread_groups']) for r in matrix],
    paired=[dict(case=r['case'], heap_bytes_per_thread=r['heap_bytes_per_thread'],
                 trace_enabled=r['trace_enabled']) for r in paired]), indent=2))
