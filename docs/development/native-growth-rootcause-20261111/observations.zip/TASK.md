# 原生内存增长根因补查

- 负责人：Codex；创建：2026-11-11；复核／到期：2026-11-18。
- 用户重点：原生内存增长；中途续导搁置。本任务不实施视频续导。
- 输入：当前工作区诊断脚本、现装 NVIDIA 621.14、Windows SDK／MSVC、现有 Python 3.13.3 与 .venv 只读依赖。
- 目标：用 CUDA／D3D 最小对照复核触发条件，核对短线程及驱动分配路径；区分根因与进程回收保护。
- 起始 F 盘可用约 47.1 GiB；预计新增峰值 256 MiB，不复制模型、运行库或完整开发环境。
- 构建：在本目录 build/ 调用现有 vcvars64.bat，用 cl /LD 编译 scripts/native_heap_trace.cpp、scripts/native_thread_activity.cpp；必要时编译原生最小线程探针。全部编译产物只在本目录。
- 重建：基础 Python 3.13.3，PYTHONPATH 指向仓库与现有 .venv/Lib/site-packages；TEMP/TMP 指向本任务；verify_p0_stability.py --task 本目录 --case native-cuda/native-device11/native-device --frames 32 --idle-seconds 60 --timeout 150 --no-gpu-snapshots，组合用 --device-cuda，D3D11 空计算用 --device-compute；追踪轮设置 DLSS5TOOL_P0_MEMORY_MAP／THREAD_ACTIVITY／HEAP_TRACE。
- 进程与资源边界：诊断自身及其精确 PID＋创建时间的后代；8 GiB 系统余量与私有提交上限；不真实耗尽内存。不更改驱动、注册表、服务、覆盖层开关或其他应用。
- 产物：原始测量、模块身份、有限元数据栈、参数和源码清单；有价值的结论及小型证据归档到 docs/development/，可复用脚本到 scripts/。
- 保留原因：排查期间保留复现材料；交付归档核验后，只清理本任务明确创建且可重建的产物，保留本登记文件。不得清整个 tmp/。
