import ctypes as C
import json
from pathlib import Path
import threading

root = Path(__file__).resolve().parent
trace = C.WinDLL(str(root / 'native_heap_trace.dll'))
trace.trace_dump.argtypes = [C.c_wchar_p]
client = C.WinDLL(str(root / 'build/heap_trace_client.dll'))
client.test_allocate.argtypes = [C.c_size_t]
client.test_allocate.restype = C.c_void_p
client.test_reallocate.argtypes = [C.c_void_p, C.c_size_t]
client.test_reallocate.restype = C.c_void_p
client.test_free.argtypes = [C.c_void_p]
counter = C.WinDLL(str(root / 'native_thread_activity.dll'))
counter.thread_activity_read.argtypes = [C.POINTER(C.c_uint64)]
values = (C.c_uint64 * 131)()
counter.thread_activity_read(values)
started, stopped = values[0], values[1]
for _ in range(50):
    thread = threading.Thread(target=lambda: None)
    thread.start()
    thread.join()
counter.thread_activity_read(values)
assert (values[0] - started, values[1] - stopped) == (50, 50)
assert values[2] == 0
patches = trace.trace_begin()
assert patches > 0

def retained(name):
    path = root / (name + '.jsonl')
    assert trace.trace_dump(str(path)) == 0
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    module, = [r for r in rows if r['kind'] == 'module' and Path(r['path']).name == 'heap_trace_client.dll']
    base, size = int(module['base'], 16), module['size']
    return sum(r['live'] for r in rows if r['kind'] == 'stack' and any(
        base <= int(frame, 16) < base + size for frame in r['frames']))

pointer = None
try:
    pointer = client.test_allocate(16 * 1024**2)
    assert pointer and retained('self-allocate') == 16 * 1024**2
    pointer = client.test_reallocate(pointer, 24 * 1024**2)
    assert pointer and retained('self-reallocate') == 24 * 1024**2
    assert client.test_free(pointer)
    pointer = None
    assert retained('self-free') == 0
finally:
    if pointer:
        client.test_free(pointer)
    restored = trace.trace_end()
assert restored == patches
result = dict(status='passed', thread_starts=50, thread_stops=50,
              unclassified=values[2], allocate=16 * 1024**2,
              reallocate=24 * 1024**2, retained_after_free=0,
              patches=patches, restored=restored)
(root / 'self-check.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
