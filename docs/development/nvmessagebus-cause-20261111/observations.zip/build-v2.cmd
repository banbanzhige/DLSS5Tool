@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b %errorlevel%
rem Reuse the verified thread counter currently loaded by the long controls.
cl /nologo /std:c++17 /O2 /Ob0 /MT /EHsc /LD /Fe:../native_message_bus_trace.dll /Fo:native_message_bus_trace.obj "F:\project\DLSS5Tool\scripts\native_message_bus_trace.cpp" /link psapi.lib advapi32.lib /IMPLIB:native_message_bus_trace.lib
if errorlevel 1 exit /b %errorlevel%
cl /nologo /Od /MT /LD /Fe:../message_trace_fixture.dll /Fo:message_trace_fixture.obj "F:\project\DLSS5Tool\tmp\nvmessagebus-cause-20261111\message_trace_fixture.cpp" /link advapi32.lib /IMPLIB:message_trace_fixture.lib
exit /b %errorlevel%
