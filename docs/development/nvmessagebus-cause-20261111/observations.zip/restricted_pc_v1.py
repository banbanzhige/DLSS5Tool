"""Separate a restricted token from a different account, without credentials.

Derives a lower-privilege token from this ordinary user's own token, creates
only this task's suspended child and arms its Job before resuming. No logon,
password, service, machine policy or privilege elevation is used.
"""
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from dlss5tool.process_job import KillOnCloseJob
from dlss5tool.memory_budget import system_memory
from scripts.verify_native_worker_recycling import job_pids

TASK = Path(__file__).resolve().parent
WORK = TASK / 'trace-restricted-pc'
WORK.mkdir(exist_ok=False)
k = C.WinDLL('kernel32', use_last_error=True)
a = C.WinDLL('advapi32', use_last_error=True)

class SidAndAttributes(C.Structure):
    _fields_ = [('sid', C.c_void_p), ('attributes', C.c_uint32)]

class Startup(C.Structure):
    _fields_ = [('cb', C.c_uint32), ('reserved', C.c_wchar_p), ('desktop', C.c_wchar_p),
        ('title', C.c_wchar_p)] + [(n, C.c_uint32) for n in (
        'x', 'y', 'width', 'height', 'chars_x', 'chars_y', 'fill', 'flags')] + [
        ('show', C.c_ushort), ('reserved_size', C.c_ushort), ('reserved_data', C.c_void_p),
        ('input', C.c_void_p), ('output', C.c_void_p), ('error', C.c_void_p)]

class Process(C.Structure):
    _fields_ = [('process', C.c_void_p), ('thread', C.c_void_p), ('pid', C.c_uint32), ('tid', C.c_uint32)]

class Security(C.Structure):
    _fields_ = [('size', C.c_uint32), ('descriptor', C.c_void_p), ('inherit', C.c_int)]

k.GetCurrentProcess.restype = C.c_void_p
k.CloseHandle.argtypes = [C.c_void_p]
k.LocalFree.argtypes = [C.c_void_p]
k.CreatePipe.argtypes = [C.POINTER(C.c_void_p), C.POINTER(C.c_void_p), C.POINTER(Security), C.c_uint32]
k.SetHandleInformation.argtypes = [C.c_void_p, C.c_uint32, C.c_uint32]
k.ResumeThread.argtypes = [C.c_void_p]
k.WaitForSingleObject.argtypes = [C.c_void_p, C.c_uint32]
k.GetExitCodeProcess.argtypes = [C.c_void_p, C.POINTER(C.c_uint32)]
k.WriteFile.argtypes = [C.c_void_p, C.c_void_p, C.c_uint32, C.POINTER(C.c_uint32), C.c_void_p]
a.OpenProcessToken.argtypes = [C.c_void_p, C.c_uint32, C.POINTER(C.c_void_p)]
a.GetTokenInformation.argtypes = [C.c_void_p, C.c_int, C.c_void_p, C.c_uint32, C.POINTER(C.c_uint32)]
a.CreateRestrictedToken.argtypes = [C.c_void_p, C.c_uint32, C.c_uint32, C.c_void_p,
    C.c_uint32, C.c_void_p, C.c_uint32, C.POINTER(SidAndAttributes), C.POINTER(C.c_void_p)]
a.ConvertStringSidToSidW.argtypes = [C.c_wchar_p, C.POINTER(C.c_void_p)]
a.IsTokenRestricted.argtypes = [C.c_void_p]
a.GetLengthSid.argtypes = [C.c_void_p]
a.CreateProcessAsUserW.argtypes = [C.c_void_p, C.c_wchar_p, C.c_wchar_p,
    C.c_void_p, C.c_void_p, C.c_int, C.c_uint32, C.c_void_p, C.c_wchar_p,
    C.POINTER(Startup), C.POINTER(Process)]

def token_user(token):
    needed = C.c_uint32()
    a.GetTokenInformation(token, 1, None, 0, C.byref(needed))
    data = C.create_string_buffer(needed.value)
    if not a.GetTokenInformation(token, 1, data, len(data), C.byref(needed)): raise C.WinError(C.get_last_error())
    return data, C.cast(data, C.POINTER(SidAndAttributes))[0].sid

token = C.c_void_p(); restricted = C.c_void_p()
read_pipe = C.c_void_p(); write_pipe = C.c_void_p()
pi = Process(); job = None; allocated = []
record = dict(processing_and_exit_passed=False, phase='initial', uses_credentials=False,
              machine_configuration_changed=False, samples=[])
began = time.monotonic()
try:
    if not a.OpenProcessToken(k.GetCurrentProcess(), 0xB, C.byref(token)): raise C.WinError(C.get_last_error())
    user_data, user_sid = token_user(token)
    entries = (SidAndAttributes * 4)()
    entries[0] = SidAndAttributes(user_sid, 0)
    for index, text in enumerate(('S-1-1-0', 'S-1-5-11', 'S-1-5-32-545'), 1):
        sid = C.c_void_p()
        if not a.ConvertStringSidToSidW(text, C.byref(sid)): raise C.WinError(C.get_last_error())
        allocated.append(sid); entries[index] = SidAndAttributes(sid, 0)
    record['phase'] = 'CreateRestrictedToken'
    if not a.CreateRestrictedToken(token, 1, 0, None, 0, None, 4, entries, C.byref(restricted)):
        raise C.WinError(C.get_last_error())
    restricted_data, restricted_sid = token_user(restricted)
    user_hash = hashlib.sha256(C.string_at(user_sid, a.GetLengthSid(user_sid))).hexdigest()
    restricted_hash = hashlib.sha256(C.string_at(restricted_sid, a.GetLengthSid(restricted_sid))).hexdigest()
    record.update(same_user=user_hash == restricted_hash, user_sid_sha256=user_hash,
        parent_restricted=bool(a.IsTokenRestricted(token)), child_token_restricted=bool(a.IsTokenRestricted(restricted)))
    assert record['same_user'] and not record['parent_restricted'] and record['child_token_restricted']
    security = Security(C.sizeof(Security), None, 1)
    if not k.CreatePipe(C.byref(read_pipe), C.byref(write_pipe), C.byref(security), 0): raise C.WinError(C.get_last_error())
    if not k.SetHandleInformation(write_pipe, 1, 0): raise C.WinError(C.get_last_error())
    with (WORK / 'console.log').open('wb') as output:
        import msvcrt
        output_handle = msvcrt.get_osfhandle(output.fileno())
        os.set_handle_inheritable(output_handle, True)
        startup = Startup(); startup.cb = C.sizeof(Startup); startup.flags = 0x100
        startup.input = read_pipe.value; startup.output = output_handle; startup.error = output_handle
        command = subprocess.list2cmdline([sys.executable, '-B', str(TASK / 'probe_calls.py'),
            '--worker', '--d3d', '--seconds', '30', '--label', 'restricted-pc'])
        mutable = C.create_unicode_buffer(command)
        record['phase'] = 'CreateProcessAsUserW'
        if not a.CreateProcessAsUserW(restricted, sys.executable, mutable, None, None, True,
            0x08000004, None, str(ROOT), C.byref(startup), C.byref(pi)):
            raise C.WinError(C.get_last_error())
        job = KillOnCloseJob.from_handle(pi.process)
        record['pid'] = pi.pid
        record['phase'] = 'owned-child'
        if k.ResumeThread(pi.thread) == 0xFFFFFFFF: raise C.WinError(C.get_last_error())
        sent = C.c_uint32()
        if not k.WriteFile(write_pipe, b'G', 1, C.byref(sent), None) or sent.value != 1:
            raise C.WinError(C.get_last_error())
        k.CloseHandle(read_pipe); read_pipe = C.c_void_p()
        k.CloseHandle(write_pipe); write_pipe = C.c_void_p()
        while k.WaitForSingleObject(pi.process, 0) == 258:
            status = system_memory()
            record['samples'].append(dict(wall=time.time(), system=status))
            if time.monotonic()-began > 90 or not status or min(status['free_commit_bytes'], status['free_physical_bytes']) < 8*1024**3:
                raise RuntimeError('Diagnostic time/headroom bound')
            time.sleep(.25)
        code = C.c_uint32()
        assert k.GetExitCodeProcess(pi.process, C.byref(code))
        record['returncode'] = code.value
        record['remaining_before_cleanup'] = job_pids(job)
        assert code.value == 0 and record['remaining_before_cleanup'] == []
    record['processing_and_exit_passed'] = True
except BaseException:
    record['error'] = traceback.format_exc()
finally:
    if job: job.close()
    elif pi.process:
        k.TerminateProcess.argtypes = [C.c_void_p, C.c_uint]
        k.TerminateProcess(pi.process, 7)
    if pi.process: k.WaitForSingleObject(pi.process, 10000)
    for handle in (pi.thread, pi.process, read_pipe, write_pipe, restricted, token):
        if handle: k.CloseHandle(handle)
    for sid in allocated: k.LocalFree(sid)
    record['elapsed_seconds'] = time.monotonic()-began
    (WORK / 'verification.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('samples', 'user_sid_sha256')}))
raise SystemExit(0 if record['processing_and_exit_passed'] else 1)
