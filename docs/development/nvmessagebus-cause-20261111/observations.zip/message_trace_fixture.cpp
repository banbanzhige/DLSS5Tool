#define WIN32_LEAN_AND_MEAN
#include <windows.h>
DWORD WINAPI empty_thread(void*) { return 0; }
extern "C" __declspec(dllexport) int fixture_calls(const wchar_t* missing_pipe) {
    HANDLE thread = CreateThread(nullptr, 0, empty_thread, nullptr, 0, nullptr);
    if (!thread) return 1;
    DWORD waited = WaitForSingleObject(thread, 10000);
    CloseHandle(thread);
    if (waited != WAIT_OBJECT_0) return 2;
    SetLastError(0x13579);
    Sleep(0);
    if (GetLastError() != 0x13579) return 3;
    if (WaitNamedPipeW(missing_pipe, 1) || GetLastError() != ERROR_FILE_NOT_FOUND) return 4;
    HANDLE file = CreateFileW(missing_pipe, GENERIC_READ, 0, nullptr, OPEN_EXISTING, 0, nullptr);
    if (file != INVALID_HANDLE_VALUE || GetLastError() != ERROR_FILE_NOT_FOUND) return 5;
    char data = 0; DWORD size = 0;
    if (ReadFile(INVALID_HANDLE_VALUE, &data, 1, &size, nullptr) || GetLastError() != ERROR_INVALID_HANDLE) return 6;
    if (WriteFile(INVALID_HANDLE_VALUE, &data, 1, &size, nullptr) || GetLastError() != ERROR_INVALID_HANDLE) return 7;
    HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, GetCurrentProcessId());
    if (!process) return 8;
    HANDLE token = nullptr;
    if (!OpenProcessToken(process, TOKEN_QUERY, &token)) { CloseHandle(process); return 9; }
    DWORD elevation = 0, needed = 0;
    const BOOL info = GetTokenInformation(token, TokenElevation, &elevation, sizeof(elevation), &needed);
    CloseHandle(token); CloseHandle(process);
    if (!info || needed != sizeof(elevation)) return 10;
    ULONG pid = 0;
    if (GetNamedPipeServerProcessId(INVALID_HANDLE_VALUE, &pid) || GetLastError() != ERROR_INVALID_HANDLE) return 11;
    return 0;
}
