"""Record own token properties only; no names, credentials or group contents."""
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import sys

k = C.WinDLL('kernel32', use_last_error=True)
a = C.WinDLL('advapi32', use_last_error=True)
k.GetCurrentProcess.restype = C.c_void_p
k.CloseHandle.argtypes = [C.c_void_p]
a.OpenProcessToken.argtypes = [C.c_void_p, C.c_uint32, C.POINTER(C.c_void_p)]
a.GetTokenInformation.argtypes = [C.c_void_p, C.c_int, C.c_void_p, C.c_uint32, C.POINTER(C.c_uint32)]
a.IsTokenRestricted.argtypes = [C.c_void_p]
a.GetLengthSid.argtypes = [C.c_void_p]
a.GetLengthSid.restype = C.c_uint32
a.GetSidSubAuthorityCount.argtypes = [C.c_void_p]
a.GetSidSubAuthorityCount.restype = C.POINTER(C.c_ubyte)
a.GetSidSubAuthority.argtypes = [C.c_void_p, C.c_uint32]
a.GetSidSubAuthority.restype = C.POINTER(C.c_uint32)
token = C.c_void_p()
assert a.OpenProcessToken(k.GetCurrentProcess(), 8, C.byref(token))

def info(kind):
    size = C.c_uint32()
    a.GetTokenInformation(token, kind, None, 0, C.byref(size))
    data = C.create_string_buffer(size.value)
    assert a.GetTokenInformation(token, kind, data, len(data), C.byref(size)), C.get_last_error()
    return data

try:
    user = info(1)
    sid = C.cast(user, C.POINTER(C.c_void_p))[0]
    sid_hash = hashlib.sha256(C.string_at(sid, a.GetLengthSid(sid))).hexdigest()
    label = info(25)
    integrity_sid = C.cast(label, C.POINTER(C.c_void_p))[0]
    count = a.GetSidSubAuthorityCount(integrity_sid)[0]
    rid = a.GetSidSubAuthority(integrity_sid, count - 1)[0]
    session = C.c_uint32()
    assert k.ProcessIdToSessionId(os.getpid(), C.byref(session))
    result = dict(pid=os.getpid(), user_sid_sha256=sid_hash,
        token_restricted=bool(a.IsTokenRestricted(token)), integrity_rid=rid,
        elevated=C.cast(info(20), C.POINTER(C.c_uint32))[0],
        app_container=C.cast(info(29), C.POINTER(C.c_uint32))[0], session_id=session.value)
finally:
    k.CloseHandle(token)
output = Path(__file__).resolve().parent / ('token-' + sys.argv[1] + '.json')
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k != 'user_sid_sha256'}))
