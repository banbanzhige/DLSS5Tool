"""Read-only final checks; no GPU load or permission changes."""
import ast
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
sys.path.insert(0, str(ROOT))
from scripts.ngx_updater_lifecycle_probe import Processes
from scripts.windows_process_context import current_context

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def save(path, data):
    path.write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8')

files = ['scripts/windows_process_context.py', 'scripts/profile_native_frame_memory.py',
         'scripts/verify_p0_stability.py', 'scripts/native_message_bus_trace.cpp',
         'scripts/compare_p0_stability.py']
source_dir = TASK/'final-sources'
source_dir.mkdir(exist_ok=True)
manifest = []
for name in files:
    data = (ROOT/name).read_bytes()
    if name.endswith('.py'):
        ast.parse(data, filename=name)
    (source_dir/Path(name).name).write_bytes(data)
    manifest.append(dict(file=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
save(TASK/'final-source-manifest.json', manifest)

smokes = []
for name, restricted in [('native-idle-context-smoke', True),
                         ('native-idle-context-ordinary-smoke', False)]:
    result = read(TASK/name/'result.json')
    context, = result['native_execution_contexts']
    assert result['processing_and_exit_passed'] and not result['remaining_before_recovery']
    assert not result['recovery'] and not result['safety_error']
    assert context['query_complete'] and context['read_only']
    assert context['token_restricted'] == restricted
    assert any((row['pid'], row['created']) == (context['pid'], context['created_filetime'])
               for row in result['observed_processes'])
    assert read(TASK/name/'source-comparison.json')['unchanged']
    smokes.append(dict(case=name, context=context, exact_process_identity_matched=True,
                       processing_and_exit_passed=True, source_runtime_unchanged=True))

identities = set()
for path in TASK.rglob('verification.json'):
    if path.parent == TASK:
        continue
    result = read(path)
    row = result.get('identity', {})
    if row.get('pid') and row.get('created'):
        identities.add((row['pid'], row['created']))
for path in TASK.glob('*/result.json'):
    for row in read(path).get('observed_processes', []):
        if row.get('created'):
            identities.add((row['pid'], row['created']))
for path in TASK.rglob('*.jsonl'):
    if path.name == 'events.jsonl':
        for line in path.read_text(encoding='utf-8-sig').splitlines():
            row = json.loads(line)
            if row.get('pid') and row.get('created'):
                identities.add((row['pid'], row['created']))

processes = Processes()
now = processes.snapshot()
active, reused, unverified = [], [], []
for row in now:
    if row['pid'] in {identity[0] for identity in identities}:
        actual = processes.identity(row)
        if not actual.get('created'):
            unverified.append(actual)
            continue
        if (actual.get('pid'), actual.get('created')) in identities:
            active.append(actual)
        else:
            reused.append(actual)
assert not active, active
assert not unverified, unverified

protected = read(TASK/'protected-user-file-hashes.json')
assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest
           for name,digest in protected.items())
diff = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, capture_output=True, text=True)
assert diff.returncode == 0, diff.stdout+diff.stderr
result = dict(python_ast_passed=True, final_sources=manifest, smokes=smokes,
              protected_user_files_unchanged=True, git_diff_check_passed=True,
              audited_process_identity_count=len(identities), active_owned_processes=active,
              audited_process_identities=[dict(pid=pid,created=created) for pid,created in sorted(identities)],
              reused_process_ids=reused, unverified_process_ids=unverified,
              current_context=current_context(), no_gpu_or_permission_mutation=True)
save(TASK/'final-checks.json', result)
print(json.dumps({k:v for k,v in result.items() if k not in ('smokes','current_context','final_sources')}))
