"""Read this process's DACL, retaining SID roles/hashes instead of user SIDs."""
import ctypes as C
import hashlib
import json
from pathlib import Path
import sys

k = C.WinDLL('kernel32', use_last_error=True)
a = C.WinDLL('advapi32', use_last_error=True)
k.GetCurrentProcess.restype = C.c_void_p
k.CloseHandle.argtypes = [C.c_void_p]
k.LocalFree.argtypes = [C.c_void_p]
a.GetSecurityInfo.argtypes = [C.c_void_p, C.c_int, C.c_uint32,
    C.c_void_p, C.c_void_p, C.POINTER(C.c_void_p), C.c_void_p, C.POINTER(C.c_void_p)]
a.GetAclInformation.argtypes = [C.c_void_p, C.c_void_p, C.c_uint32, C.c_int]
a.GetAce.argtypes = [C.c_void_p, C.c_uint32, C.POINTER(C.c_void_p)]
a.ConvertSidToStringSidW.argtypes = [C.c_void_p, C.POINTER(C.c_void_p)]
a.GetLengthSid.argtypes = [C.c_void_p]
a.OpenProcessToken.argtypes = [C.c_void_p, C.c_uint32, C.POINTER(C.c_void_p)]
a.GetTokenInformation.argtypes = [C.c_void_p, C.c_int, C.c_void_p, C.c_uint32, C.POINTER(C.c_uint32)]
token = C.c_void_p()
assert a.OpenProcessToken(k.GetCurrentProcess(), 8, C.byref(token))
size = C.c_uint32()
a.GetTokenInformation(token, 1, None, 0, C.byref(size))
user = C.create_string_buffer(size.value)
assert a.GetTokenInformation(token, 1, user, len(user), C.byref(size))
user_sid = C.cast(user, C.POINTER(C.c_void_p))[0]
self_hash = hashlib.sha256(C.string_at(user_sid, a.GetLengthSid(user_sid))).hexdigest()
k.CloseHandle(token)
dacl = C.c_void_p(); descriptor = C.c_void_p()
target = k.GetCurrentProcess()
token_target = C.c_void_p()
if '--token' in sys.argv:
    assert a.OpenProcessToken(k.GetCurrentProcess(), 0x20008, C.byref(token_target))
    target = token_target
code = a.GetSecurityInfo(target, 6, 4, None, None, C.byref(dacl), None, C.byref(descriptor))
result = dict(query_error=code, object='token' if token_target else 'process', entries=[])
if code == 0 and dacl:
    try:
        info = (C.c_uint32 * 3)()
        assert a.GetAclInformation(dacl, info, C.sizeof(info), 2)
        for index in range(info[0]):
            ace = C.c_void_p()
            assert a.GetAce(dacl, index, C.byref(ace))
            kind = C.cast(ace, C.POINTER(C.c_ubyte))[0]
            flags = C.cast(ace, C.POINTER(C.c_ubyte))[1]
            row = dict(type=kind, flags=flags)
            if kind in (0, 1):
                mask = C.c_uint32.from_address(ace.value + 4).value
                sid = ace.value + 8
                sid_hash = hashlib.sha256(C.string_at(sid, a.GetLengthSid(sid))).hexdigest()
                text_pointer = C.c_void_p()
                assert a.ConvertSidToStringSidW(sid, C.byref(text_pointer))
                text = C.wstring_at(text_pointer)
                k.LocalFree(text_pointer)
                role = {'S-1-5-18':'LocalSystem','S-1-5-32-544':'Administrators',
                    'S-1-1-0':'Everyone','S-1-5-32-545':'Users','S-1-5-11':'AuthenticatedUsers',
                    'S-1-3-4':'OwnerRights'}.get(text)
                role = 'self' if sid_hash == self_hash else role or ('logon' if text.startswith('S-1-5-5-') else 'other')
                row.update(mask=hex(mask), sid_role=role, sid_sha256=sid_hash)
            result['entries'].append(row)
    finally:
        k.LocalFree(descriptor)
if token_target: k.CloseHandle(token_target)
output = Path(__file__).resolve().parent / ('acl-' + sys.argv[1] + '.json')
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(query_error=code,entries=[{k:v for k,v in r.items() if k != 'sid_sha256'} for r in result['entries']]),indent=2))
