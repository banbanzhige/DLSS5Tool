"""Task-owned CUDA/D3D controls with a bounded observational MessageBus trace."""
import argparse
import contextlib
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
TASK = Path(__file__).resolve().parent

def save(path, value):
    path.write_text(json.dumps(value, indent=2, default=str) + '\n', encoding='utf-8')

def worker(args, work):
    if sys.stdin.buffer.read(1) != b'G':
        raise RuntimeError('Missing Job startup gate')
    os.environ.update(TEMP=str(work), TMP=str(work), DLSS5TOOL_P0_MEMORY_MAP='1',
        DLSS5TOOL_P0_THREAD_ACTIVITY='1', DLSS5TOOL_P0_HEAP_TRACE='0',
        DLSS5TOOL_SETTINGS_PATH=str(work / 'settings.json'), DLSS5TOOL_DISABLE_UPDATE_CHECK='1')
    from dlss5tool import paths
    state = work / 'state'; state.mkdir()
    paths.state_path = lambda name: state / name
    from scripts import profile_native_frame_memory as profile
    def event(kind, **data):
        with (work / 'events.jsonl').open('a', encoding='utf-8') as out:
            out.write(json.dumps(dict(event=kind.replace('heap-trace', 'message-trace'),
                wall=time.time(), pid=os.getpid(), **data)) + '\n')
    def start_trace(directory, callback):
        kernel = C.WinDLL('kernel32', use_last_error=True)
        kernel.GetModuleHandleW.argtypes = [C.c_wchar_p]
        kernel.GetModuleHandleW.restype = C.c_void_p
        deadline = time.monotonic() + 3
        while not kernel.GetModuleHandleW('NvMessageBus.dll') and time.monotonic() < deadline:
            time.sleep(.01)
        if not kernel.GetModuleHandleW('NvMessageBus.dll'):
            raise RuntimeError('MessageBus did not become resident; incomplete tracing coverage')
        trace = C.WinDLL(str(TASK / 'native_message_bus_trace.dll'))
        trace.message_trace_dump.argtypes = [C.c_wchar_p]
        patches = trace.message_trace_begin()
        assert patches > 0
        def dump(path):
            actual = Path(path).with_name(Path(path).name.replace('native-heap-', 'message-api-'))
            return trace.message_trace_dump(str(actual))
        trace.trace_dump = dump
        trace.trace_end = trace.message_trace_end
        callback('message-trace-start', patches=patches,
                 scope='observational API IAT wrappers; MessageBus/diag/CUDA only')
        return trace, patches
    profile.start_heap_trace = start_trace
    control = SimpleNamespace(idle_seconds=args.seconds, device_compute=args.d3d,
        device_timing=False, device_work=False, device_readback=False)
    event('starting')
    manager = contextlib.nullcontext()
    if args.system_query_mask or args.system_token_read:
        from self_query_acl import allow_system_query
        manager = allow_system_query(args.system_query_mask, work / 'self-acl-variant.json',
            token_read=args.system_token_read, token_mask=args.system_token_mask)
    with manager:
        result = profile.device_control(control, work, event, create_device=args.d3d, d3d11=args.d3d, cuda=True)
    event('closed')
    save(work / 'worker-result.json', result)

def supervise(args, work):
    from dlss5tool.memory_budget import system_memory
    from dlss5tool.process_job import KillOnCloseJob
    from scripts.ngx_updater_lifecycle_probe import Processes
    from scripts.verify_p0_stability import Memory, checked_path
    from scripts.verify_native_worker_recycling import job_pids
    checked_path(work); work.mkdir(exist_ok=False)
    child = job = None
    measured_sources = [ROOT / 'scripts/native_message_bus_trace.cpp', Path(__file__).resolve(),
        ROOT / 'scripts/profile_native_frame_memory.py', ROOT / 'scripts/native_thread_activity.cpp',
        TASK / 'native_message_bus_trace.dll', TASK / 'native_thread_activity.dll', TASK / 'self_query_acl.py']
    def manifest():
        values = []
        for source in measured_sources:
            with source.open('rb') as stream:
                values.append(dict(path=str(source.relative_to(ROOT)),
                    sha256=hashlib.file_digest(stream, 'sha256').hexdigest()))
        return values
    record = dict(processing_and_exit_passed=False, samples=[], gpu_queries=False,
                  api_trace='observational, bounded; no payloads', source_manifest_before=manifest())
    began = time.monotonic()
    try:
        with (work / 'console.log').open('wb') as output:
            command = [sys.executable, '-B', str(Path(__file__).resolve()), '--worker',
                       '--seconds', str(args.seconds), '--label', args.label]
            if args.d3d: command.append('--d3d')
            if args.system_query_mask: command.extend(['--system-query-mask', str(args.system_query_mask)])
            environment = dict(os.environ)
            if args.system_token_read:
                from self_query_acl import token_id
                environment['DLSS5TOOL_P0_PARENT_TOKEN_ID'] = str(token_id())
                command.extend(['--system-token-read', '--system-token-mask', str(args.system_token_mask)])
            child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=output,
                stderr=subprocess.STDOUT, cwd=ROOT, env=environment, creationflags=subprocess.CREATE_NO_WINDOW)
            job = KillOnCloseJob(child)
            processes = Processes(); memory = Memory(processes)
            row, = [r for r in processes.snapshot() if r['pid'] == child.pid]
            identity = processes.identity(row)
            assert identity.get('created')
            record['identity'] = identity
            child.stdin.write(b'G'); child.stdin.close()
            while child.poll() is None:
                status = system_memory()
                sample = dict(wall=time.time(), seconds=time.monotonic()-began,
                              memory=memory.read(identity), system=status)
                record['samples'].append(sample)
                if (sample['seconds'] > args.seconds+60 or sample['memory'].get('private_bytes', 0) > 2*1024**3
                        or not status or min(status['free_commit_bytes'], status['free_physical_bytes']) < 8*1024**3):
                    raise RuntimeError('Diagnostic time/private/headroom limit')
                time.sleep(.25)
            child.wait(timeout=10)
            record['remaining_before_cleanup'] = job_pids(job)
            assert child.returncode == 0 and record['remaining_before_cleanup'] == []
        record['processing_and_exit_passed'] = True
    except BaseException:
        record['error'] = traceback.format_exc()
    finally:
        if child and child.stdin and not child.stdin.closed: child.stdin.close()
        if job: job.close()
        if child:
            if child.poll() is None: child.terminate()
            child.wait(timeout=10); record['returncode'] = child.returncode
        record['elapsed_seconds'] = time.monotonic()-began
        record['source_manifest_after'] = manifest()
        record['source_unchanged'] = record['source_manifest_before'] == record['source_manifest_after']
        if not record['source_unchanged']: record['processing_and_exit_passed'] = False
        save(work / 'verification.json', record)
    print(json.dumps({k:v for k,v in record.items() if k not in
        ('samples', 'source_manifest_before', 'source_manifest_after')}), flush=True)
    return 0 if record['processing_and_exit_passed'] else 1

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--worker', action='store_true')
    parser.add_argument('--d3d', action='store_true')
    parser.add_argument('--seconds', type=int, default=30)
    parser.add_argument('--label', required=True)
    parser.add_argument('--system-query-mask', type=lambda s:int(s,0), default=0,
                        choices=(0, 0x1000, 0x1400, 0x21000))
    parser.add_argument('--system-token-read', action='store_true')
    parser.add_argument('--system-token-mask', type=lambda s:int(s,0), default=0x20008,
                        choices=(8, 0x20000, 0x20008))
    args = parser.parse_args()
    assert 10 <= args.seconds <= 60 and args.label.replace('-', '').isalnum()
    work = TASK / ('trace-' + args.label)
    if args.worker: worker(args, work)
    else: raise SystemExit(supervise(args, work))
