"""Open only the observed local pipe, query server identity, send no bytes."""
import ctypes as C
import json
from pathlib import Path
import sys

k = C.WinDLL('kernel32', use_last_error=True)
k.CreateFileW.argtypes = [C.c_wchar_p, C.c_uint32, C.c_uint32, C.c_void_p, C.c_uint32, C.c_uint32, C.c_void_p]
k.CreateFileW.restype = C.c_void_p
k.GetNamedPipeServerProcessId.argtypes = [C.c_void_p, C.POINTER(C.c_uint32)]
k.GetNamedPipeServerSessionId.argtypes = [C.c_void_p, C.POINTER(C.c_uint32)]
k.CloseHandle.argtypes = [C.c_void_p]
name = r'\\.\pipe\NvMessageBusBroadcastNVIDIA.Display.Driver'
handle = k.CreateFileW(name, 0x12008b, 0, None, 3, 0x40000000, None)
result = dict(pipe=name, open_error=0, bytes_sent=0, bytes_read=0)
if handle == C.c_void_p(-1).value:
    result['open_error'] = C.get_last_error()
else:
    try:
        pid = C.c_uint32()
        session = C.c_uint32()
        ok = k.GetNamedPipeServerProcessId(handle, C.byref(pid))
        result.update(server_pid=pid.value if ok else None, server_pid_query_error=0 if ok else C.get_last_error())
        ok = k.GetNamedPipeServerSessionId(handle, C.byref(session))
        result.update(server_session=session.value if ok else None, session_query_error=0 if ok else C.get_last_error())
    finally:
        k.CloseHandle(handle)
output = Path(__file__).resolve().parent / ('pipe-identity-' + sys.argv[1] + '.json')
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
