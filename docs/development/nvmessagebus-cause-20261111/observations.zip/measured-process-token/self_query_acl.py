"""Temporary LocalSystem query ACE on this diagnostic process only."""
import contextlib
import ctypes as C
import hashlib
import json
import os

class Trustee(C.Structure):
    _fields_ = [('multiple', C.c_void_p), ('operation', C.c_int), ('form', C.c_int),
                ('type', C.c_int), ('sid', C.c_void_p)]

class Access(C.Structure):
    _fields_ = [('permissions', C.c_uint32), ('mode', C.c_int), ('inheritance', C.c_uint32),
                ('trustee', Trustee)]

def token_id():
    k = C.WinDLL('kernel32', use_last_error=True)
    a = C.WinDLL('advapi32', use_last_error=True)
    k.GetCurrentProcess.restype = C.c_void_p
    k.CloseHandle.argtypes = [C.c_void_p]
    a.OpenProcessToken.argtypes = [C.c_void_p, C.c_uint32, C.POINTER(C.c_void_p)]
    a.GetTokenInformation.argtypes = [C.c_void_p, C.c_int, C.c_void_p, C.c_uint32, C.POINTER(C.c_uint32)]
    handle = C.c_void_p()
    assert a.OpenProcessToken(k.GetCurrentProcess(), 8, C.byref(handle))
    try:
        size = C.c_uint32()
        a.GetTokenInformation(handle, 10, None, 0, C.byref(size))
        data = C.create_string_buffer(size.value)
        assert a.GetTokenInformation(handle, 10, data, len(data), C.byref(size))
        return C.c_uint64.from_buffer(data).value
    finally:
        k.CloseHandle(handle)

@contextlib.contextmanager
def allow_system_query(mask, output, *, token_read=False):
    assert mask in (0x1000, 0x1400, 0x21000)
    k = C.WinDLL('kernel32', use_last_error=True)
    a = C.WinDLL('advapi32', use_last_error=True)
    k.GetCurrentProcess.restype = C.c_void_p
    k.LocalFree.argtypes = [C.c_void_p]
    k.CloseHandle.argtypes = [C.c_void_p]
    a.GetSecurityInfo.argtypes = [C.c_void_p, C.c_int, C.c_uint32,
        C.c_void_p, C.c_void_p, C.POINTER(C.c_void_p), C.c_void_p, C.POINTER(C.c_void_p)]
    a.SetSecurityInfo.argtypes = [C.c_void_p, C.c_int, C.c_uint32,
        C.c_void_p, C.c_void_p, C.c_void_p, C.c_void_p]
    a.ConvertStringSidToSidW.argtypes = [C.c_wchar_p, C.POINTER(C.c_void_p)]
    a.SetEntriesInAclW.argtypes = [C.c_uint32, C.POINTER(Access), C.c_void_p, C.POINTER(C.c_void_p)]
    a.OpenProcessToken.argtypes = [C.c_void_p, C.c_uint32, C.POINTER(C.c_void_p)]
    process = k.GetCurrentProcess()
    old = C.c_void_p(); descriptor = C.c_void_p(); system_sid = C.c_void_p(); new = C.c_void_p()
    token = C.c_void_p(); token_old = C.c_void_p(); token_sd = C.c_void_p(); token_new = C.c_void_p()
    result = dict(scope='current diagnostic process only', mask=hex(mask),
                  account_or_token_changed=False, installed_files_changed=False,
                  granted=False, restored=False, token_read_variant=token_read, token_granted=False)
    def digest(acl):
        length = C.c_ushort.from_address(acl.value + 2).value
        return hashlib.sha256(C.string_at(acl, length)).hexdigest()
    def save():
        output.write_text(json.dumps(result, indent=2) + '\n')
    try:
        code = a.GetSecurityInfo(process, 6, 4, None, None, C.byref(old), None, C.byref(descriptor))
        assert code == 0 and old, code
        result['old_dacl_sha256'] = digest(old)
        assert a.ConvertStringSidToSidW('S-1-5-18', C.byref(system_sid))
        if token_read:
            own_id = token_id()
            parent_id = int(os.environ['DLSS5TOOL_P0_PARENT_TOKEN_ID'])
            result.update(primary_token_id=own_id, parent_primary_token_id=parent_id,
                          private_primary_token=own_id != parent_id)
            assert own_id != parent_id, 'Refuse to mutate a primary token shared with the supervisor'
            assert a.OpenProcessToken(process, 0x60008, C.byref(token))
            code = a.GetSecurityInfo(token, 6, 4, None, None, C.byref(token_old), None, C.byref(token_sd))
            assert code == 0 and token_old, code
            result['old_token_dacl_sha256'] = digest(token_old)
            token_access = Access(0x20008, 1, 0, Trustee(None, 0, 0, 5, system_sid))
            code = a.SetEntriesInAclW(1, C.byref(token_access), token_old, C.byref(token_new))
            assert code == 0, code
            code = a.SetSecurityInfo(token, 6, 4, None, None, token_new, None)
            assert code == 0, code
            result['token_granted'] = True
            result['token_access_mask'] = '0x20008'
        access = Access(mask, 1, 0, Trustee(None, 0, 0, 5, system_sid))
        code = a.SetEntriesInAclW(1, C.byref(access), old, C.byref(new))
        assert code == 0, code
        code = a.SetSecurityInfo(process, 6, 4, None, None, new, None)
        assert code == 0, code
        result['granted'] = True
        save()
        try:
            yield result
        finally:
            code = a.SetSecurityInfo(process, 6, 4, None, None, old, None)
            result['restore_error'] = code
            assert code == 0, code
            actual = C.c_void_p(); actual_sd = C.c_void_p()
            try:
                code = a.GetSecurityInfo(process, 6, 4, None, None, C.byref(actual), None, C.byref(actual_sd))
                assert code == 0 and actual, code
                result['restored_dacl_sha256'] = digest(actual)
                result['restored'] = result['old_dacl_sha256'] == result['restored_dacl_sha256']
                assert result['restored'], 'DACL bytes differ after restoration'
            finally:
                if actual_sd: k.LocalFree(actual_sd)
            save()
    finally:
        if result['token_granted']:
            code = a.SetSecurityInfo(token, 6, 4, None, None, token_old, None)
            result['token_restore_error'] = code
            assert code == 0, code
            actual = C.c_void_p(); actual_sd = C.c_void_p()
            try:
                code = a.GetSecurityInfo(token, 6, 4, None, None, C.byref(actual), None, C.byref(actual_sd))
                assert code == 0 and actual, code
                result['restored_token_dacl_sha256'] = digest(actual)
                result['token_restored'] = result['old_token_dacl_sha256'] == result['restored_token_dacl_sha256']
                assert result['token_restored']
            finally:
                if actual_sd: k.LocalFree(actual_sd)
        if token_new: k.LocalFree(token_new)
        if token_sd: k.LocalFree(token_sd)
        if token: k.CloseHandle(token)
        if new: k.LocalFree(new)
        if system_sid: k.LocalFree(system_sid)
        if descriptor: k.LocalFree(descriptor)
        save()
