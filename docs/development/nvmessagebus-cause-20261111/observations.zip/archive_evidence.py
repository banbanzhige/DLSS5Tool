"""Archive this registered task, verify every entry, and prepare exact cleanup.

Does not delete anything. No installed binaries are read into the archive.
"""
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import zipfile

TASK = Path(__file__).absolute().parent
ROOT = TASK.parents[1]
DEST = ROOT/'docs/development/nvmessagebus-cause-20261111'

def checked(path):
    path = path.absolute()
    for part in [path, *path.parents]:
        if part.exists() and part.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise RuntimeError('Reparse point rejected: '+str(part))
    assert path.resolve() == path
    return path

def save(path, data):
    checked(path).write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8')

checked(TASK); checked(DEST)
assert TASK == ROOT/'tmp/nvmessagebus-cause-20261111'
assert (TASK/'TASK.md').is_file()
free_before = shutil.disk_usage(ROOT).free
assert free_before > 15*1024**3+256*1024**2
DEST.mkdir(exist_ok=True)
previous = DEST/'observations.zip'
previous_hash = None
if previous.exists():
    record = json.loads((DEST/'archive-verification.json').read_text())
    previous_hash = hashlib.sha256(previous.read_bytes()).hexdigest()
    assert record['archive_sha256'] == previous_hash
    assert not record['cleanup_completed']
kernel = C.WinDLL('kernel32', use_last_error=True)
kernel.CreateFileW.argtypes = [C.c_wchar_p,C.c_uint32,C.c_uint32,C.c_void_p,
                              C.c_uint32,C.c_uint32,C.c_void_p]
kernel.CreateFileW.restype = C.c_void_p
kernel.CloseHandle.argtypes = [C.c_void_p]
for path in TASK.rglob('*'):
    checked(path)
files = sorted(p for p in TASK.rglob('*') if p.is_file())
binary_hashes = []
for path in files:
    if path.suffix.lower() in ('.exe','.dll'):
        binary_hashes.append(dict(file=path.relative_to(TASK).as_posix(),
            sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
# Explicit whitelist: only this project's compiled observers/fixtures/probe.
assert {Path(row['file']).name for row in binary_hashes} <= {
    'message_trace_fixture.dll','native_message_bus_trace.dll','native_thread_activity.dll',
    'native_driver_thread_probe.exe','native_heap_trace.dll'}
for path in files:
    handle = kernel.CreateFileW(str(path),0x80000000,0,None,3,0x80,None)
    if handle == C.c_void_p(-1).value:
        raise C.WinError(C.get_last_error())
    kernel.CloseHandle(handle)
archive = checked(DEST/'observations-candidate.zip')
assert not archive.exists()
index = []
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for path in files:
        data = path.read_bytes()
        name = path.relative_to(TASK).as_posix()
        index.append(dict(file=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        out.writestr(name,data)
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None
    assert source.namelist() == [row['file'] for row in index]
    for row in index:
        data = source.read(row['file'])
        assert len(data) == row['bytes']
        assert hashlib.sha256(data).hexdigest() == row['sha256']
        assert (TASK/row['file']).read_bytes() == data
# The verified predecessor remains intact until every replacement entry passes.
# Same-directory atomic promotion; checked paths reject reparse points above.
checked(previous); checked(archive)
os.replace(archive, previous)
archive = previous
save(DEST/'archive-index.json',index)
for name in ('verification.json','final-checks.json','final-source-manifest.json'):
    (DEST/name).write_bytes((TASK/name).read_bytes())
items = [p for p in TASK.iterdir() if p.name != 'TASK.md']
cleanup = [dict(path=str(checked(p)),directory=p.is_dir()) for p in sorted(items)]
result = dict(archive=str(archive.relative_to(ROOT)),
    archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    archive_bytes=archive.stat().st_size,entries=len(index),
    uncompressed_bytes=sum(r['bytes'] for r in index),
    all_entry_lengths_and_sha256_verified=True,source_bytes_equal=True,
    binary_whitelist_verified=True,binaries=binary_hashes,exclusive_open_all_files_passed=True,
    source_and_destination_reparse_check_passed=True,free_bytes_before_archive=free_before,
    free_bytes_after_archive=shutil.disk_usage(ROOT).free,
    cleanup_completed=False,cleanup_plan=cleanup,retained_task_file='TASK.md',review_date='2026-11-18')
result['replaced_previously_verified_archive_sha256'] = previous_hash
save(DEST/'archive-verification.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ('cleanup_plan','binaries')},indent=2))
