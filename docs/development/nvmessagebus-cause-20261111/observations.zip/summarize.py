"""Summarize fixed observations without treating ordinary exit as a plateau."""
import bisect
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts.compare_p0_stability import window_stats

TASK = Path(__file__).resolve().parent
MIB = 1024**2

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def lines(path):
    return [json.loads(s) for s in path.read_text(encoding='utf-8-sig').splitlines()]

def trace_case(path):
    verification = read(path / 'verification.json')
    row = dict(case=path.name, processing_and_exit_passed=verification['processing_and_exit_passed'],
        error=verification.get('error'), source_unchanged=verification.get('source_unchanged'))
    frame_files = list(path.glob('*-frame-memory.jsonl'))
    if not frame_files:
        return row
    profiles = lines(frame_files[0])
    first, last = profiles[0], profiles[-1]
    def messages(profile):
        return sum(g['started'] for g in profile['thread_activity']['groups'] if 'NvMessageBus.dll' in g.get('module',''))
    row.update(profile_span_seconds=last['wall']-first['wall'],
        thread_starts_delta=last['thread_activity']['started']-first['thread_activity']['started'],
        messagebus_starts_delta=messages(last)-messages(first),
        messagebus_total_observed=messages(last))
    regions = list(path.glob('*-frame-memory-regions.jsonl'))
    if regions:
        data = lines(regions[0])
        row['default_heap_allocated_delta'] = data[-1]['default_heap']['allocated']-data[0]['default_heap']['allocated']
    api_file = path / 'message-api-final.jsonl'
    if api_file.is_file():
        data = lines(api_file)
        modules = [r for r in data if r['kind']=='module']
        def resolve(address):
            value = int(address,16)
            return next((dict(module=Path(m['path']).name,offset=hex(value-int(m['base'],16)))
                for m in modules if int(m['base'],16)<=value<int(m['base'],16)+m['size']),dict(address=address))
        row['api_summary'] = next(r for r in data if r['kind']=='summary')
        row['api_entries'] = [dict(r,caller=resolve(r['caller']),
            frames=[resolve(a) for a in r['frames']]) for r in data if r['kind']=='api']
        row['messagebus_iat_covered'] = any(r['kind']=='patch' and
            resolve(r['module']).get('module')=='NvMessageBus.dll' for r in data)
    acl = path / 'self-acl-variant.json'
    if acl.is_file():
        row['temporary_acl_variant'] = read(acl)
        assert row['temporary_acl_variant']['restored']
        if row['temporary_acl_variant'].get('token_granted'):
            assert row['temporary_acl_variant']['token_restored']
    return row

def native_case(path, kind, continuous):
    verification, worker = read(path / 'result.json'), read(path / 'worker-result.json')
    events = lines(path / 'events.jsonl')
    samples = read(path / 'memory-samples.json')
    profiles = lines(path / (kind+'-frame-memory.jsonl'))
    frames = [e for e in events if e['event']=='frame']
    begin = next(e['wall'] for e in events if e['event']=='first-output') if continuous else next(e['wall'] for e in events if e['event']=='idle-start')
    end = frames[-1]['wall'] if continuous else next(e['wall'] for e in events if e['event']=='idle-end')
    end_sample = min((s for s in samples if begin <= s['wall'] <= end),key=lambda s:abs(s['wall']-end))
    target = max((p for p in end_sample['processes'] if 'private_bytes' in p),key=lambda p:p['private_bytes'])
    pid, created = target['pid'], target['created']
    values = [(s['wall'],p['private_bytes']) for s in samples if begin <= s['wall'] <= end
        for p in s['processes'] if (p['pid'],p['created'])==(pid,created) and 'private_bytes' in p]
    # Independently cross-check the selected native owner against in-worker
    # memory checkpoints rather than attributing the whole tree to it.
    keys = [s['wall'] for s in samples]
    errors, sample_offsets, candidate_separations = [], [], []
    for profile in profiles:
        index = bisect.bisect_left(keys,profile['wall'])
        candidates = samples[max(0,index-1):min(len(samples),index+1)]
        nearest = min(candidates,key=lambda s:abs(s['wall']-profile['wall']))
        reference = [profile[k]['private_bytes'] for k in ('memory_before_gc','memory_after_gc')]
        distances = sorted((min(abs(p['private_bytes']-r) for r in reference),
                            p['pid'],p['created']) for p in nearest['processes'] if 'private_bytes' in p)
        # Samples and in-process checkpoints are not atomic. Do not impose an
        # invented byte-accuracy gate on first-frame imports/GC; independently
        # require the same process to be the unique closest memory owner.
        assert (distances[0][1],distances[0][2]) == (pid,created)
        assert len(distances)>1 and distances[1][0]>distances[0][0]
        errors.append(distances[0][0])
        candidate_separations.append(distances[1][0]-distances[0][0])
        sample_offsets.append(abs(nearest['wall']-profile['wall']))
    assert errors and max(sample_offsets)<1
    windows = {str(warm):window_stats([v for v in values if v[0]>=begin+warm])
               for warm in ((10,30,60) if continuous else (10,))}
    primary = windows['30' if continuous else '10']
    gate = primary['sufficient_samples'] and primary['mib_per_minute'] <= .25 and abs(primary['delta_bytes']) <= 16*MIB
    medians = []
    for index in range(6 if continuous else 1):
        selected = [v[1] for v in values if begin+index*300<=v[0]<begin+(index+1)*300]
        if selected: medians.append(statistics.median(selected))
    first_threads,last_threads=profiles[0]['thread_activity'],profiles[-1]['thread_activity']
    msg = lambda t:sum(g['started'] for g in t['groups'] if 'NvMessageBus.dll' in g.get('module',''))
    return dict(case=path.name,processing_and_exit_passed=verification['processing_and_exit_passed'],
        source_runtime_unchanged=read(path/'source-comparison.json')['unchanged'],
        safety_error=verification['safety_error'], remaining_before_recovery=verification['remaining_before_recovery'],
        supervisor_recovery=verification['recovery'], frames=worker['frames'],
        configured_window_seconds=verification['run_arguments']['run_seconds' if continuous else 'idle_seconds'],
        elapsed_seconds=verification['elapsed_seconds'], worker_pid=pid, worker_created=created,
        selection='largest private commit at window end, exact PID+creation, cross-checked against native checkpoints',
        profile_private_match_median_error=statistics.median(errors),
        profile_private_match_max_error=max(errors),
        profile_private_match_min_candidate_separation=min(candidate_separations),
        profile_match_max_sample_offset_seconds=max(sample_offsets),
        profile_count=len(profiles), profile_span_seconds=profiles[-1]['wall']-profiles[0]['wall'],
        private_windows=windows, five_minute_private_medians=medians,
        primary_window_gate_passed=gate, gate=dict(max_growth_mib_per_minute=.25,max_absolute_window_delta_mib=16),
        messagebus_starts_delta=msg(last_threads)-msg(first_threads),
        messagebus_total_observed=msg(last_threads),
        thread_activity_has_multiple_checkpoints=len(profiles)>1,
        total_thread_starts_delta=last_threads['started']-first_threads['started'],
        python_traced_delta=profiles[-1]['python_after_gc_bytes']-profiles[0]['python_after_gc_bytes'],
        source_scope='existing production ProcessLive/ProcessSuperResolution, synthetic frames, ordinary account',
        all_user_scenarios_certified=False)

trace_cases=[trace_case(p) for p in sorted(TASK.glob('trace-*')) if (p/'verification.json').is_file()]
ordinary=[]
for name,kind,continuous in [('native-nr-ordinary-nr','nr',False),('native-sr-ordinary-vsr','sr',False),
    ('native-nr-ordinary-long-nr','nr',True),('native-sr-ordinary-long-vsr','sr',True)]:
    ordinary.append(native_case(TASK/name,kind,continuous))

paired=[]
for p in sorted(TASK.glob('driver-threads-ordinary-confirm-*')):
    verification=read(p/'verification.json'); raw=lines(p/'console.jsonl')
    samples=[r for r in raw if r['kind']=='sample']
    first=next(r for r in samples if r['threads_completed']==10000); last=samples[-1]
    paired.append(dict(case=p.name,processing_and_exit_passed=verification['processing_and_exit_passed'],
        trace_enabled=verification['trace_enabled'],source_unchanged=verification['source_unchanged'],
        target_unchanged=verification['target_unchanged'],
        heap_bytes_per_thread=(last['heap_allocated']-first['heap_allocated'])/(last['threads_completed']-first['threads_completed'])))

factor_names=['trace-factor-none','trace-factor-process','trace-factor-token','trace-factor-both']
manifests=[read(TASK/n/'verification.json')['source_manifest_before'] for n in factor_names]
assert all(m==manifests[0] for m in manifests)
for name in factor_names:
    assert read(TASK/name/'verification.json')['source_unchanged']
for case in ordinary:
    assert case['processing_and_exit_passed'] and case['source_runtime_unchanged']
    assert not case['remaining_before_recovery'] and not case['supervisor_recovery'] and not case['safety_error']
snapshot_proof=[]
for name in ('verify_p0_stability.py','profile_native_frame_memory.py'):
    source=TASK/'measured-common'/name
    source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
    matched=[]
    for case in ordinary:
        expected=next(r['sha256'] for r in read(TASK/case['case']/'run-manifest-before.json')['files']
                      if r['file']=='scripts/'+name)
        assert source_hash==expected
        matched.append(case['case'])
    snapshot_proof.append(dict(source=name,sha256=source_hash,matched_measured_manifest=True,
                               matched_cases=matched))

summary=dict(traces=trace_cases,ordinary_native=ordinary,ordinary_driver_thread_controls=paired,
    factorial_sources_identical=True,measured_common_source_snapshots=snapshot_proof,
    hypotheses=dict(process_query_rights_only_sufficient=False,token_read_control_boundary_validated=True,
                    ordinary_account_fast_growth_reproduced=False,driver_per_thread_retention_remains=True),
    limitations=['One local GPU/driver, synthetic low-resolution native loads.',
        'NR/VSR 30-minute processing windows overlapped; compare memory, not performance.',
        'No injection/stack capture inside the system broker; static family-code and causal permission controls support the token boundary.',
        'Initial CUDA-only API trace missed late-loaded MessageBus; not used as evidence of absent API calls.',
        'First restricted-PC token setup failed importing ctypes before CUDA; not a native-memory result.',
        'No production permission changes, driver replacement or machine configuration changes.'])
(TASK/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(ordinary=[dict(case=r['case'],frames=r['frames'],pid=r['worker_pid'],
    gate=r['primary_window_gate_passed'],windows=r['private_windows']) for r in ordinary],
    bare_driver=paired),indent=2))
