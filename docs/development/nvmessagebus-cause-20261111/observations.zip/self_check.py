import ctypes as C
import json
import os
from pathlib import Path

task = Path(__file__).resolve().parent
fixture = C.WinDLL(str(task / 'message_trace_fixture.dll'))
fixture.fixture_calls.argtypes = [C.c_wchar_p]
missing = r'\\.\pipe\DLSS5Tool-Missing-' + str(os.getpid())
assert fixture.fixture_calls(missing) == 0
trace = C.WinDLL(str(task / 'native_message_bus_trace.dll'))
trace.message_trace_dump.argtypes = [C.c_wchar_p]
patches = trace.message_trace_begin()
assert patches > 0
try:
    assert fixture.fixture_calls(missing) == 0
    output = task / 'self-check-api-v2.jsonl'
    assert trace.message_trace_dump(str(output)) == 0
finally:
    restored = trace.message_trace_end()
assert restored == patches
assert fixture.fixture_calls(missing) == 0
rows = [json.loads(s) for s in output.read_text().splitlines()]
apis = [r for r in rows if r['kind'] == 'api']
assert {r['api'] for r in apis} == set(range(1, 13))
assert all(r['calls'] == 1 for r in apis)
assert next(r for r in rows if r['kind'] == 'summary')['dropped'] == 0
result = dict(status='passed', original_and_traced_and_restored_results_equal=True,
    thread_joined=True, missing_pipe_error=2, invalid_handle_error=6,
    success_last_error_preserved=True, api_kinds=12, patched=patches, restored=restored)
(task / 'self-check-v2.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
