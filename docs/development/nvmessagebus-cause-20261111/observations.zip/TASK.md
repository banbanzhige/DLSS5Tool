# NvMessageBus 线程风暴触发条件深查

- 用户授权：2026-11-11「帮我查到底」；目标为 DLSS5Tool 原生内存增长，中途续导搁置。
- 负责人：Codex；创建：2026-11-11；复核日期：2026-11-18。
- 预算：F 盘起始约 47.1 GiB；新增峰值 256 MiB；复用 Python 3.13.3、现有 pefile／LLVM／MSVC，模型和驱动只读。
- 输入：本机 621.14 的 NvMessageBus.dll、nvdiagclt64.dll、nvcuda64.dll 和 nvwgf2umx.dll；上一轮证据 docs/development/native-growth-rootcause-20261111/。
- 活动：离线读取 PE 导入／导出／字符串及有限反汇编；在本任务创建、由 Job 限定的最小 CUDA／D3D 进程内记录线程创建栈和命名管道调用的路径／状态／时延。无通信载荷、无其他应用注入。
- 网络：仅公开源码和官方文档查询；不访问未知服务、不上传本机样本、不执行 reverse-skill 仓库脚本或安装工具。
- 机器配置：本阶段不替换 DLL、改驱动、注册表或服务配置；全局环境变更另列具体方案。临时进程环境及自己的观察型 IAT 包装在任务内复原／退出。
- 重建：任务内分析脚本用基础 Python -B，PYTHONPATH 指向现有 .venv；native trace 用现有 vcvars64.bat、cl /O2 /Ob0 /MT /EHsc /LD；所有编译输出及 TEMP/TMP 指向本任务。
- 输出：固定源哈希、调用栈、参数、失败记录和单变量结果；可复用脚本到 scripts/，结论和必要证据到 docs/development/。
- 收尾：归档逐文件校验后，仅删除本任务明确创建且可重建的产物，保留 TASK.md；不清理其他 tmp 内容。所有已知子进程 PID＋创建时间均须核验退休。

## 已完成与恢复位置

- 同沙箱四格及权限位拆分对照：仅给本次独立主令牌对象的 LocalSystem READ_CONTROL 即停止风暴；TOKEN_QUERY／进程查询单独无效。所有临时对象 DACL 已按哈希核对恢复；不是产品方案。
- 普通入口 NR／VSR 各五分钟空闲及三十分钟处理通过本轮数值门槛；独立裸线程普通入口仍复现约 184 bytes／线程。原用户完整负载、617.42 历史触发条件未提前归因。
- 新增上下文采集在长跑结束后接入；measured-common 保留实测脚本，final-sources 为后续版本，不能混用。
- 75 个已知 PID＋创建时间退休检查通过；两种上下文各十秒纯空闲集成烟测通过。
- 原始记录、失败变体、自检及各代精确源码归档到 docs/development/nvmessagebus-cause-20261111/observations.zip，逐文件长度／SHA256 清单为 archive-index.json。
- 最终结论为 docs/development/NVMESSAGEBUS_TOKEN_ACL_ROOT_CAUSE_20261111.md；实际清理字节数、空间前后差及 ZIP 校验以 archive-verification.json 为准。
- 除本登记外的任务内容均可由该证据归档精确恢复；重新运行实验前恢复到登记任务目录并按 scope 核对权限边界，不运行压缩包中的二进制作为产品。
