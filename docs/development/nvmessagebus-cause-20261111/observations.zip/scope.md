# Scope

- auth.status: granted
- authorization_source: 本聊天用户「帮我查到底」，延续本项目原生内存增长排查及此前隔离诊断授权。
- network_profile: offline-sample
- sample: 当前已安装 NVIDIA 621.14 四份模块；身份取 docs/development/native-growth-rootcause-20261111/installed-module-metadata.json。
- allowed: 读取模块及公开资料；编译本项目诊断代码；在本任务新建、启动 gate 后绑定 Job 的自有进程内观察线程与命名管道 API 的调用，不修改其返回语义；读取相关服务状态及错误记录。
- excluded: 其他应用注入、驱动指令修改、未知堆释放、机器全局配置／安装变更、对外通信载荷、凭证或用户媒体采集、主动网络扫描。
- tools: 已核实的本机 pefile、LLVM objdump、MSVC 及项目自身隔离／归档脚本；仅阅读 reverse-skill 指引，不执行其脚本或启动其服务。
- controlled_variant: 为隔离已观察到的 DACL 差异，仅对本任务当前最小诊断进程临时授予 LocalSystem PROCESS_QUERY_LIMITED_INFORMATION（必要时再比较查询／读控制位），保持账户／令牌／文件／服务不变；结束还原原 DACL 并校验，不修改外部进程、持久 ACL 或机器配置。
- controlled_token_variant: 进一步只对本任务子进程的独立主令牌对象临时增加 LocalSystem TOKEN_READ（查询＋读控制，不允许复制、模拟或分配令牌）；先核验其 TokenId 与监督器不同，拒绝修改共享令牌；结束还原令牌和进程 DACL 并逐字节校验。账户、权限内容和机器策略不变，不读取凭证。
