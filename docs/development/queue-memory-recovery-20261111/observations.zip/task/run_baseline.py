"""Read pre-change product modules from Git; never replace workspace files."""
import importlib.abc
import importlib.util
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
NAMES=('gui','memory_budget','deferred_error','dlss_host_process','super_resolution',
       'gpu_export_process','resident_sr','resident_sr_worker')
sources={'dlss5tool.'+name:subprocess.check_output(['git','show','HEAD:dlss5tool/'+name+'.py'],cwd=ROOT)
         for name in NAMES}

class Baseline(importlib.abc.MetaPathFinder,importlib.abc.Loader):
    def find_spec(self,fullname,path=None,target=None):
        if fullname in sources:
            return importlib.util.spec_from_loader(fullname,self)
    def create_module(self,spec):return None
    def exec_module(self,module):
        module.__file__=str(ROOT/('dlss5tool/'+module.__name__.rsplit('.',1)[1]+'.py'))
        exec(compile(sources[module.__name__],module.__file__,'exec'),module.__dict__)

sys.meta_path.insert(0,Baseline())
if __name__=='__main__':
 import pytest
 raise SystemExit(pytest.main(['-q','--tb=short','--maxfail=3','-p','no:cacheprovider',
    '--basetemp=tmp/queue-memory-recovery-20261111/pytest-baseline-fixed',
    '--junitxml=tmp/queue-memory-recovery-20261111/baseline-fixed.xml',
    'tests/test_export_queue.py','tests/test_queue_output.py','tests/test_export_gui.py',
    'tests/test_dlss_host_process.py','tests/test_dlss_host_lifetime.py',
    'tests/test_super_resolution.py','tests/test_process_job.py','tests/test_parallel_lifetime.py',
    'tests/test_p0_owner_retirement.py','tests/test_memory_coordination.py','tests/test_memory_budget.py',
    'tests/test_memory_policy_calibration.py','tests/test_resident_sr.py','tests/test_i18n.py',
    '-k','not failed_worker_preserves_pressure_after_retirement']))
