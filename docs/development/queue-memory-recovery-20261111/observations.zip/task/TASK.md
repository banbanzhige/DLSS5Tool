# Queue recovery after native worker memory pressure

- Owner: Codex / maintainer request in this chat, 2026-11-11.
- Review: 2026-11-18, no automatic deletion.
- Purpose: preserve structured memory errors, retire existing owners, wait for
  verified headroom and retry the current queued item at most twice.
- Scope: whole-item retries for images/videos; completed outputs stay completed.
  No mid-video continuation, precision changes, driver changes or runtime swaps.
- Inputs: existing `.venv`, production runtimes and synthetic test fixtures.
- Starting F free: 50,537,394,176 bytes, approximately 47.1 GiB.
- Additional disk peak budget: 128 MiB; reuse all dependencies, small frames only.
- Tests: base Python with existing `.venv/Lib/site-packages` on PYTHONPATH;
  TEMP/TMP here; pytest -p no:cacheprovider --basetemp=<this task>/pytest;
  queue recovery, structured error/lifetime, queue persistence/output and memory
  policy tests only, plus a bounded real NR/VSR pressure-recovery probe.
- Preserve reusable probes in scripts/ and conclusions/evidence in
  docs/development/. Verify archives before cleaning only this task's outputs.
- Never delete shared tmp dependencies, user media, existing packages or backups.

