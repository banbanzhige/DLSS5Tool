"""Archive bounded recovery evidence before removing this task's fixtures."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from scripts.verify_p0_stability import checked_path
task=checked_path(Path(__file__).resolve().parent)
out=checked_path(ROOT/'docs/development/queue-memory-recovery-20261111')
assert task==ROOT/'tmp/queue-memory-recovery-20261111'
out.mkdir(exist_ok=False)

def save(name,value):
    (out/name).write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))

native=json.loads((task/'native-final-verification.json').read_text())
assert native['passed'] and native['source_and_runtime_unchanged']
assert not native['remaining_before_supervisor_cleanup']
before=json.loads((task/'native-final-manifest-before.json').read_text())
after=json.loads((task/'native-final-manifest-after.json').read_text())
assert before==after
for item in after['files']:
    assert hashlib.sha256((ROOT/item['file']).read_bytes()).hexdigest()==item['sha256'],item['file']
records=json.loads((task/'native-final/result.json').read_text())
assert len(records)==2 and all(r['passed'] and len(r['attempts'])==2 for r in records)
payload={}
for label in ('native','native-fixed','native-final'):
    for path in sorted((task/label).rglob('*')):
        path=checked_path(path)
        if path.is_file():payload['runs/'+label+'/'+path.relative_to(task/label).as_posix()]=path.read_bytes()
    for name in ('console.log','manifest-before.json','manifest-after.json','samples.json','verification.json'):
        path=checked_path(task/(label+'-'+name))
        payload['runs/'+path.name]=path.read_bytes()
summaries={}
for name in ('core.xml','related.xml','final.xml','baseline-fixed.xml','admission.xml','verified.xml'):
    path=checked_path(task/name)
    suites=ET.fromstring(path.read_bytes())
    rows=suites.findall('.//testcase')
    summaries[name]=dict(xml_tests=len(rows),failures=[dict(classname=r.get('classname'),name=r.get('name'))
        for r in rows if r.find('failure') is not None or r.find('error') is not None])
    payload['tests/'+name]=path.read_bytes()
assert not summaries['verified.xml']['failures']
assert len(summaries['baseline-fixed.xml']['failures'])==1
assert len(summaries['final.xml']['failures'])==1
assert summaries['baseline-fixed.xml']['failures']==summaries['final.xml']['failures']
if (task/'baseline.xml').is_file():
    payload['invalid/baseline-without-entry-guard.xml']=(task/'baseline.xml').read_bytes()
for name in ('run_baseline.py','TASK.md','collect_recovery_evidence.py'):
    payload['task/'+name]=checked_path(task/name).read_bytes()
source_names=sorted({r['file'] for r in after['files'] if r['file'].endswith('.py')} | {
    'tests/test_queue_memory_recovery.py','tests/test_resident_sr.py','tests/test_memory_budget.py',
    'locales/zh_CN.json','locales/en_US.json'})
for name in source_names:payload['sources/final/'+name]=checked_path(ROOT/name).read_bytes()
baseline_names=('gui.py','memory_budget.py','deferred_error.py','dlss_host_process.py','super_resolution.py',
    'gpu_export_process.py','resident_sr.py','resident_sr_worker.py')
for name in baseline_names:
    payload['sources/baseline/'+name]=subprocess.check_output(['git','show','cfc58fc:dlss5tool/'+name],cwd=ROOT)
payload['sources/baseline/test_memory_budget.py']=subprocess.check_output(
    ['git','show','cfc58fc:tests/test_memory_budget.py'],cwd=ROOT)
index=[dict(file=name,bytes=len(value),sha256=hashlib.sha256(value).hexdigest()) for name,value in sorted(payload.items())]
assert sum(r['bytes'] for r in index)<128*1024**2
archive=out/'observations.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as destination:
    for name,value in sorted(payload.items()):
        info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED
        destination.writestr(info,value,compresslevel=9)
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    for row in index:assert hashlib.sha256(saved.read(row['file'])).hexdigest()==row['sha256']
save('archive-index.json',index)
save('tests.json',summaries)
save('native-result.json',records)
verification=dict(date='2026-11-11',base_commit='cfc58fc',
    implemented='bounded whole-item queue recovery after structured memory pressure',
    environment=dict(gpu='RTX 4070 SUPER',driver='621.14',python='3.13.3',ram_gib=64),
    final_tests=dict(passed_items=224,passed_subtests=89,failures=0),
    automatic_retry_limit=2,wait_timeout_seconds=120,poll_milliseconds=250,
    recovery_margin_bytes=256*1024**2,stable_headroom_seconds=.5,
    existing_memory_safety_reserves_unchanged=True,
    native=native,real_pressure_allocated=False,simulated_snapshot_in_first_worker_only=True,
    final_probe_scope='headless widget/export fixtures; actual queue dispatcher, recovery callbacks, owners and native runtimes',
    native_output_hashes_equal=True,completed_output_unchanged=True,
    baseline_before_fixture_isolation=summaries['baseline-fixed.xml'],
    current_before_fixture_isolation=summaries['final.xml'],
    fixture_change='Explicitly disable the shared pool in the named unpooled cache test; assertions unchanged',
    invalid_baseline_run_excluded=True,
    first_real_vsr_run_failed_idle_zero_allocation_guard=True,
    subsequent_fixed_and_final_runs_passed=True,
    original_memory_plateau_p0_closed=False,mid_video_continuation_implemented=False,
    no_driver_runtime_precision_or_global_settings_changed=True,
    archived_files=len(index),archived_source_and_observation_bytes=sum(r['bytes'] for r in index),
    artifacts=[dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
        for p in (archive,out/'archive-index.json',out/'tests.json',out/'native-result.json')])
save('verification.json',verification)
print(json.dumps(dict(files=len(index),archive_bytes=archive.stat().st_size,output=str(out)),ensure_ascii=False))
