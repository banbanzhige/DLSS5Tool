"""Read completed cases, never overwrite their raw measurements."""
import hashlib
import json
from pathlib import Path
import sys

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
sys.path.insert(0,str(ROOT))
from scripts.compare_p0_stability import window_stats
from scripts.verify_p0_stability import checked_path

def read(path):return json.loads(path.read_text(encoding='utf-8'))
def lines(path):return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
summary={'baseline_commit':'716a53f','memory_limits':{'mib_per_minute':.25,'absolute_window_delta_mib':16},
         'long_runs':[],'resident':[],'repeats':[],'direct_close':[]}
for kind in ('nr','sr'):
    work=TASK/('native-'+kind+'-fixed1080-long')
    result=read(work/'result.json');worker=read(work/'worker-result.json')
    context=read(next(work.glob('*-execution-context-*.json')))
    identity=context['pid'],context['created_filetime']
    events=lines(work/'events.jsonl');samples=read(work/'memory-samples.json')
    frames=[r for r in events if r['event']=='frame']
    windows={}
    for warmup in (10,30,60):
        values=[(s['wall'],r['private_bytes']) for s in samples
                if frames[0]['wall']+warmup<=s['wall']<=frames[-1]['wall']
                for r in s['processes'] if (r['pid'],r['created'])==identity and 'private_bytes' in r]
        stats=window_stats(values)
        stats['passed']=stats['sufficient_samples'] and stats['mib_per_minute']<=.25 and abs(stats['delta_bytes'])<=16*1024**2
        windows[str(warmup)]=stats
    checkpoints=lines(work/(kind+'-frame-memory.jsonl'))
    def bus(row):
        return sum(r['started'] for r in row['thread_activity']['groups'] if 'nvmessagebus.dll' in r['module'].lower())
    activity=dict(checkpoints=len(checkpoints),checkpoint_span_seconds=checkpoints[-1]['wall']-checkpoints[0]['wall'],
                  first_bus_threads=bus(checkpoints[0]),last_bus_threads=bus(checkpoints[-1]),
                  messagebus_thread_delta=bus(checkpoints[-1])-bus(checkpoints[0]),
                  all_thread_delta=checkpoints[-1]['thread_activity']['started']-checkpoints[0]['thread_activity']['started'])
    unchanged=read(work/'source-comparison.json')['unchanged']
    summary['long_runs'].append(dict(case=kind,actual_dimensions=[1920,1080],
        input_dimensions=[1920,1080] if kind=='nr' else [960,540],worker_pid=identity[0],created=identity[1],
        frames=worker['frames'],elapsed_seconds=result['elapsed_seconds'],windows_after_warmup_seconds=windows,
        thread_activity=activity,source_runtime_unchanged=unchanged,status=result['status'],
        safety_error=result['safety_error'],remaining=result['remaining_before_recovery'],recovery=result['recovery'],
        peak_tree_private_bytes=result['peak_tree_private_bytes'],
        passed=result['status']=='passed' and unchanged and not result['safety_error'] and not result['remaining_before_recovery']
            and not result['recovery'] and windows['30']['passed'] and activity['messagebus_thread_delta']==0))
for work in sorted(TASK.glob('resident-*')):
    if not (work/'verification.json').is_file():continue
    row=read(work/'verification.json')
    result=row.get('result',{})
    summary['resident'].append(dict(case=work.name,**{k:row.get(k) for k in
        ('status','passed','error','elapsed_seconds','cancel_to_retirement_seconds','output_bytes',
         'output_sha256','source_runtime_unchanged','workers_after_retirement','transaction_directories_remaining')},
        worker_retirement=result.get('worker_retirement'),output_media=row.get('output_media'),
        parent_token_restricted=row['parent_context']['token_restricted']))
for stem in ('sdr96','hdr96'):
    first=read(TASK/('resident-'+stem)/'verification.json')
    second=read(TASK/('resident-'+stem+'repeat')/'verification.json')
    summary['repeats'].append(dict(case=stem,output_file_sha256_equal=first['output_sha256']==second['output_sha256'],
        frame_hashes_equal=first['result']['frame_hashes']==second['result']['frame_hashes']))
for name in ('cuda-close-fixed-r2','cuda-close-ordinary','cuda-close-syncdiag'):
    summary['direct_close'].append(dict(case=name,**read(TASK/name/'verification.json')))
protected=read(TASK/'protected-user-file-hashes.json')
summary['protected_user_files_unchanged']=all(hashlib.sha256(checked_path(ROOT/name).read_bytes()).hexdigest()==digest
                                            for name,digest in protected.items())
summary['task_current_bytes']=sum(p.stat().st_size for p in TASK.rglob('*') if p.is_file())
(TASK/'verification-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
for row in summary['long_runs']:
    print(json.dumps({k:row[k] for k in ('case','frames','passed','thread_activity')}|
        {'memory_30s':row['windows_after_warmup_seconds']['30']}))
print(json.dumps({'protected_user_files_unchanged':summary['protected_user_files_unchanged'],
                  'task_current_bytes':summary['task_current_bytes']}))
