"""Archive owned diagnostic evidence, without copying runtimes or deleting files."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import zipfile

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
sys.path.insert(0,str(ROOT))
from scripts.verify_p0_stability import checked_path
from scripts.ngx_updater_lifecycle_probe import Processes

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def digest(data):return hashlib.sha256(data).hexdigest()
def save(path,data):checked_path(path).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')

assert checked_path(TASK).is_relative_to(ROOT/'tmp') and (TASK/'TASK.md').is_file()
assert shutil.disk_usage(TASK).free>16*1024**3
destination=checked_path(ROOT/'docs/development/native-final-validation-20261111')
assert not destination.exists()

commands=[]
for kind in ('nr','sr'):
    commands.append(dict(label='native-'+kind+'-fixed1080-long',context='sandbox',
        python='C:/Users/PC/AppData/Local/Programs/Python/Python313/python.exe',
        arguments=['-B','scripts/verify_p0_stability.py','--task',str(TASK),'--case','native-'+kind,
            '--label','fixed1080-long','--frames','32','--native-width','960','--run-seconds','1800',
            '--timeout','1950','--no-gpu-snapshots'],
        environment={'PYTHONPATH':str(ROOT/'.venv/Lib/site-packages'),'TEMP':str(TASK),'TMP':str(TASK),
                     'DLSS5TOOL_P0_THREAD_ACTIVITY':'1','DLSS5TOOL_P0_MEMORY_MAP':'1'}))
for label in ('fixed-r2','ordinary'):
    commands.append(dict(label='cuda-close-'+label,context='ordinary' if label=='ordinary' else 'sandbox',
        python='C:/Users/PC/AppData/Local/Programs/Python/Python313/python.exe',
        arguments=['-B','scripts/verify_cuda_vsr_close.py','--task',str(TASK),'--label',label,'--timeout','60'],
        environment={'PYTHONPATH':str(ROOT/'.venv/Lib/site-packages'),'DLSS5TOOL_P0_THREAD_ACTIVITY':'1'}))
commands.append(dict(label='cuda-close-syncdiag',context='sandbox',python=str(ROOT/'.venv/Scripts/python.exe'),
    arguments=['-B',str(TASK/'process_sync_diagnostic.py')],environment={'DLSS5TOOL_P0_THREAD_ACTIVITY':'1'}))
v1={'sdr96','hdr96','sdr96repeat','hdr96repeat','sdrcancel','sdr1800','sdrenhance','hdrenhance'}
v2={'sdrenhance-r2','hdrenhance-r2','sdrordinary','hdrordinary'}
for directory in sorted(TASK.glob('resident-*')):
    label=directory.name.removeprefix('resident-')
    hdr=label.startswith('hdr');enhance='enhance' in label
    source='source-sdr1800.mp4' if label in ('sdrcancel','sdr1800') else ('source-pq96.mp4' if hdr else 'source-sdr96.mp4')
    args=['-B','scripts/verify_resident_acceptance.py','--task',str(TASK),'--source',str(TASK/source),'--label',label]
    if hdr:args+=['--hdr']
    if enhance:args+=['--enhance']
    if label=='sdrcancel':args+=['--cancel-at','24']
    elif label!='sdr1800':args+=['--audit']
    commands.append(dict(label=directory.name,context='ordinary' if 'ordinary' in label else 'sandbox',
        python=str(ROOT/'.venv/Scripts/python.exe'),arguments=args,
        script_snapshot='measured-resident-harness-v1.py' if label in v1 else
            'measured-resident-harness-v2.py' if label in v2 else 'source_snapshots/scripts/verify_resident_acceptance.py'))
save(TASK/'run-commands.json',commands)

# Revalidate the actual optional component manifests after the tests. This is
# additional post-test evidence, not a retroactive pre-test hash snapshot.
from dlss5tool.cuda_vsr_runtime import load_components as vsr_components
from dlss5tool.gpu_export_runtime import load_components as encoder_components
from dlss5tool.resident_sr_runtime import load_components as sdr_components
from dlss5tool.resident_hdr_runtime import load_components as hdr_components
components={name:loader() for name,loader in (('cuda_vsr',vsr_components),('encoder',encoder_components),
    ('resident_sdr',sdr_components),('resident_hdr',hdr_components))}
assert all(components.values())
save(TASK/'component-validation-after.json',dict(post_test_only=True,components=components,
    manifests=[dict(file=str(p.relative_to(ROOT)),sha256=digest(p.read_bytes())) for p in
        (ROOT/'runtime'/name/'manifest.json' for name in ('vsr-cuda','gpu-export','resident-sr','resident-hdr'))]))

# Follow recorded identities, never find/terminate processes by image name.
known=set();resident_pids=set()
for path in TASK.glob('*/result.json'):
    for row in read(path).get('observed_processes',[]):
        if row.get('created'):known.add((row['pid'],row['created']))
for path in TASK.glob('cuda-close-*/samples.json'):
    for sample in read(path):
        for row in sample['processes']:
            if row.get('created'):known.add((row['pid'],row['created']))
for path in TASK.glob('resident-*/verification.json'):
    row=read(path)
    assert all(not p['present'] for p in row['workers_after_retirement'])
    resident_pids.update(p['pid'] for p in row['workers_after_retirement'])
processes=Processes();current={r['pid']:r for r in processes.snapshot()}
active=[]
for pid,created in sorted(known):
    if pid in current:
        now=processes.identity(current[pid])
        if now.get('created')==created:active.append(now)
resident_pid_records=[processes.identity(current[pid]) for pid in sorted(resident_pids) if pid in current]
assert not active and not resident_pid_records,(active,resident_pid_records)
save(TASK/'retirement-verification.json',dict(exact_identity_count=len(known),resident_worker_count=len(resident_pids),
    active_owned_processes=active,resident_worker_pids_still_present=resident_pid_records))

snapshots={
 'scripts/verify_cuda_vsr_close.py':[TASK/'failed-close-harness-v1.py',TASK/'measured-close-harness-v2.py'],
 'scripts/verify_resident_acceptance.py':[TASK/'measured-resident-harness-v1.py',TASK/'measured-resident-harness-v2.py']}
sources=set();provenance=[]
for manifest in sorted(TASK.glob('*/**/*manifest-*.json')):
    data=read(manifest)
    for row in data.get('files',[]):
        path=checked_path(ROOT/row['file']);expected=row['sha256']
        candidates=[path,*snapshots.get(row['file'],[])]
        matched=next((p for p in candidates if p.is_file() and digest(p.read_bytes())==expected),None)
        assert matched is not None,(str(manifest),row)
        provenance.append(dict(manifest=str(manifest.relative_to(TASK)),file=row['file'],
                               sha256=expected,matching_file=str(matched.relative_to(ROOT))))
        if path.is_relative_to(ROOT) and not path.is_relative_to(TASK) and path.suffix in ('.py','.cpp','.h','.hlsl','.hlsli'):
            sources.add(path)
for name in ('scripts/verify_cuda_vsr_close.py','scripts/verify_resident_acceptance.py',
    'scripts/compare_p0_stability.py','scripts/ngx_updater_lifecycle_probe.py','scripts/verify_native_worker_recycling.py',
    'dlss5tool/resident_sr.py','dlss5tool/resident_sr_worker.py','dlss5tool/device_sr_plan.py',
    'dlss5tool/resident_sr_runtime.py','dlss5tool/resident_hdr_runtime.py','dlss5tool/device_consumers.py',
    'dlss5tool/cuda_frame.py','dlss5tool/cuda_session.py','dlss5tool/cuda_vsr.py',
    'dlss5tool/cuda_vsr_runtime.py','dlss5tool/gpu_export_runtime.py','dlss5tool/gpu_video_export.py'):
    sources.add(checked_path(ROOT/name))
save(TASK/'manifest-source-provenance.json',provenance)

owned=[checked_path(p) for p in sorted(TASK.rglob('*')) if p.is_file()]
for directory in TASK.rglob('*'):checked_path(directory)
assert sum(p.stat().st_size for p in owned)+32*1024**2<1024**3
destination.mkdir()
archive=checked_path(destination/'observations.zip')
entries=[];omitted=[];cleanup=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as stream:
    for path in owned:
        data=path.read_bytes();item=dict(file=str(path.relative_to(TASK)).replace('\\','/'),bytes=len(data),sha256=digest(data))
        if path.name!='TASK.md':cleanup.append(dict(path=str(path),bytes=len(data),sha256=item['sha256']))
        if path.suffix=='.mp4':omitted.append(item);continue
        arc='raw/'+item['file'];stream.writestr(arc,data);entries.append(dict(archive_path=arc,**item))
    for path in sorted(sources):
        data=path.read_bytes();arc='source_snapshots/'+str(path.relative_to(ROOT)).replace('\\','/')
        stream.writestr(arc,data);entries.append(dict(archive_path=arc,bytes=len(data),sha256=digest(data)))
with zipfile.ZipFile(archive) as stream:
    assert len(stream.namelist())==len(entries) and stream.testzip() is None
    for item in entries:
        data=stream.read(item['archive_path'])
        assert len(data)==item['bytes'] and digest(data)==item['sha256']
archive_data=archive.read_bytes()
save(destination/'archive-index.json',dict(entries=entries,omitted_rebuildable_media=omitted,
    archive_sha256=digest(archive_data),archive_bytes=len(archive_data),
    manifest_provenance_entries=len(provenance),rebuild_commands='raw/run-commands.json',
    media_generator='raw/generate_media.py',source_media_commands='raw/media-sources.json'))
save(destination/'cleanup-plan.json',dict(task=str(TASK),files=cleanup,
    directories=[str(p) for p in sorted(TASK.rglob('*'),key=lambda p:len(p.parts),reverse=True) if p.is_dir()]))
checked_path(destination/'verification-summary.json').write_bytes((TASK/'verification-summary.json').read_bytes())
save(destination/'archive-verification.json',dict(archive_sha256=digest(archive_data),archive_bytes=len(archive_data),
    entries=len(entries),uncompressed_bytes=sum(r['bytes'] for r in entries),
    all_entry_sha256_and_lengths_verified=True,manifest_provenance_entries=len(provenance),
    reparse_checks_passed=True,known_process_identity_count=len(known),active_owned_processes=active,
    omitted_rebuildable_media_bytes=sum(r['bytes'] for r in omitted),cleanup_completed=False,
    source_task_bytes=sum(p.stat().st_size for p in owned)))
print(json.dumps(dict(archive_bytes=len(archive_data),entries=len(entries),
    provenance_entries=len(provenance),omitted_media=len(omitted),cleanup_files=len(cleanup),
    active_owned_processes=active)),flush=True)
