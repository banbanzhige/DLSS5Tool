"""Diagnostic only: add LocalSystem SYNCHRONIZE to a gated owned child's process.

This tests one sandbox teardown hypothesis. Never changes the product, parent,
service, installed runtime or token policy. The child remains in its kill Job.
"""
import hashlib
import json
import os
from pathlib import Path
import struct
import sys
from types import SimpleNamespace
from unittest.mock import patch

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
sys.path.insert(0, str(ROOT))
from scripts.verify_cuda_vsr_close import main, save
from dlss5tool import process_job
from dlss5tool.nvidia_token_compat import _Windows, _aces, _SYSTEM

original = process_job.KillOnCloseJob
record = {'diagnostic_only': True, 'permission_mask': 0x100000,
          'scope': 'gated_owned_child_process',
          'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}

def owned_job(child, **kwargs):
    job = original(child, **kwargs)
    try:
        api = _Windows()
        handle = int(child._handle)
        assert api.pid(handle) == child.pid != os.getpid() and api.running(handle)
        parent = api.k.GetCurrentProcess()
        parent_acl = api.dacl(parent)
        before = api.dacl(handle)
        assert before is not None
        rows, end = _aces(before)
        assert rows and all(kind == 0 and flags == 0 for kind, flags, raw in rows)
        addition = struct.pack('<BBHI', 0, 0, 8+len(_SYSTEM), 0x100000) + _SYSTEM
        after = bytearray(before[:end] + addition + before[end:])
        struct.pack_into('<HH', after, 2, len(after), len(rows)+1)
        assert _aces(after)[0][:-1] == rows
        try:
            api.set_dacl(handle, bytes(after))
            assert api.dacl(handle) == bytes(after)
            assert api.dacl(parent) == parent_acl
        except BaseException:
            api.set_dacl(handle, before)
            assert api.dacl(handle) == before
            raise
        record.update(worker_pid=child.pid, applied=True, parent_process_dacl_unchanged=True,
                      old_dacl_sha256=hashlib.sha256(before).hexdigest(),
                      new_dacl_sha256=hashlib.sha256(after).hexdigest())
        save(TASK/'process-sync-diagnostic.json', record)
        return job
    except BaseException:
        job.close()
        raise

with patch.object(process_job, 'KillOnCloseJob', owned_job):
    code = main(SimpleNamespace(task=TASK, label='syncdiag', timeout=60,
                                worker=False, control_off=False))
raise SystemExit(code)
