"""Small reproducible sources with audio; no user media or environment copies."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from scripts.verify_p0_stability import checked_path
from dlss5tool.video_export import find_ffmpeg,probe_video_stream

task=checked_path(Path(__file__).resolve().parent)
assert (task/'TASK.md').is_file() and shutil.disk_usage(task).free>16*1024**3
rows=[]
for name,frames,hdr in [('source-sdr96',96,False),('source-pq96',96,True),('source-sdr1800',1800,False)]:
    path=checked_path(task/(name+'.mp4'))
    assert not path.exists()
    codec=(['-c:v','libx265','-preset','ultrafast','-pix_fmt','yuv420p10le',
        '-x265-params','pools=2:frame-threads=1:log-level=error:colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc',
        '-color_primaries','bt2020','-color_trc','smpte2084','-colorspace','bt2020nc'] if hdr else
        ['-c:v','libx264','-preset','ultrafast','-crf','24','-pix_fmt','yuv420p',
         '-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709'])
    command=[find_ffmpeg(),'-hide_banner','-loglevel','error','-n','-f','lavfi',
        '-i','testsrc2=size=1920x1080:rate=30','-f','lavfi','-i','sine=frequency=880:sample_rate=48000',
        '-map','0:v:0','-map','1:a:0','-frames:v',str(frames),'-t',str(frames/30),
        '-threads','2',*codec,'-color_range','tv','-c:a','aac','-b:a','128k','-movflags','+faststart',str(path)]
    result=subprocess.run(command,capture_output=True,text=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
    (task/(name+'-generate.log')).write_text(result.stderr,encoding='utf-8')
    result.check_returncode()
    info=probe_video_stream(find_ffmpeg(),path)
    assert info['frames']==frames and (info['width'],info['height'])==(1920,1080) and info['is_hdr']==hdr,info
    rows.append(dict(file=path.name,bytes=path.stat().st_size,command=command,metadata=info))
    print(json.dumps(dict(source=path.name,bytes=path.stat().st_size,frames=frames,hdr=hdr)),flush=True)
(task/'media-sources.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
