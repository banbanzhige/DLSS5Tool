# NR/VSR process recycling and feature rebuild validation

- Owner: Codex / maintainer request in this chat, 2026-11-11.
- Review date: 2026-11-18; no automatic deletion.
- Purpose: compare persistent versus recycled production NR/VSR workers; check
  parameter updates and same-process feature rebuilds for VRAM accumulation.
- Inputs: synthetic gradient frames, existing project sources, `.venv` dependencies
  and verified `runtime/` DLLs. No package/runtime downloads or system changes.
- Starting free disk: F approximately 47.07 GiB; C approximately 57.37 GiB.
- Additional disk peak budget: 128 MiB; no complete dependency copies or videos.
- Runtime limits: job private commit < 8 GiB, free RAM/commit >= 8 GiB, bounded
  operation timeout and test duration. Only the test's gated Windows Job is owned.
- Rebuild: base Python 3.13.3 with PYTHONPATH=.venv/Lib/site-packages, TEMP/TMP set
  here, then `python -B scripts/verify_native_worker_recycling.py --task
  tmp/nr-recycle-validation-20261111 --case <case> --label <unique-label>`.
- Cases: nr-hold, nr-recycle, sr-hold, sr-recycle, nr-parameters, nr-rebuild.
- Formal hold/recycle: three 60-second windows; rebuild: 30 cycles, one second
  settling. Pilot runs are diagnostic preflight, not formal acceptance.
- Evidence destination: docs/development/native-worker-recycling-20261111/;
  human-readable conclusion in docs/development/NATIVE_WORKER_RECYCLING_20261111.md.
- Cleanup: after verifying small evidence archives and preserving the reusable
  script, remove only this task's generated logs/fixtures; retain this TASK.md.
- No product settings, driver services, registry, or installed apps are modified.

