"""Freeze this task's small raw observations with exact measured probe sources."""
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts.summarize_native_worker_recycling import summarize
from scripts.verify_p0_stability import checked_path

task = checked_path(Path(__file__).resolve().parent)
output = checked_path(ROOT/'docs/development/native-worker-recycling-20261111')
assert task == ROOT/'tmp/nr-recycle-validation-20261111'
output.mkdir(exist_ok=False)
records, payload = [], {}
for result_path in sorted(task.glob('*/result.json')):
    work = checked_path(result_path.parent)
    records.append(summarize(work))
    for path in sorted(work.rglob('*')):
        path = checked_path(path)
        if path.is_file():
            payload['cases/'+work.name+'/'+path.relative_to(work).as_posix()] = path.read_bytes()

source_paths = [task/'probe-measured-pilot.py.txt', task/'probe-measured-current.py.txt',
    task/'probe-next.py', ROOT/'scripts/verify_native_worker_recycling.py']
sources = {}
for path in source_paths:
    value = checked_path(path).read_bytes()
    digest = hashlib.sha256(value).hexdigest()
    name = 'sources/probe-'+digest+'.py.txt'
    payload[name] = value
    sources[digest] = name
for path in (ROOT/'scripts/summarize_native_worker_recycling.py', task/'TASK.md', Path(__file__).resolve()):
    payload['sources/'+path.name] = checked_path(path).read_bytes()
for row in records:
    measured = json.loads((task/row['name']/'manifest-before.json').read_text())['probe_sha256']
    assert measured in sources, (row['name'], measured)

formal_names = ('nr-hold-formal','nr-recycle-formal','sr-hold-formal','sr-recycle-formal',
    'nr-parameters-formal','nr-rebuild-formal','sr-recycle-recovery-recheck')
by_name = {row['name']:row for row in records}
formal = [by_name[name] for name in formal_names]
assert all(r['result']['processing_and_exit_passed'] and r['result']['unchanged'] for r in formal)
assert all(r['result']['unchanged'] and not r['result']['gpu_errors'] for r in records)
counts = {}
for name in ('nr-parameters-formal', 'nr-rebuild-formal'):
    text = (task/name/'cycle-29-host.log').read_text(errors='replace')
    counts[name] = dict(create_calls=len(re.findall(r'CreateFeature\(18\)', text)),
                       resize_calls=text.count('=== resize Feature 18'))
assert counts['nr-parameters-formal'] == dict(create_calls=1, resize_calls=0)
assert counts['nr-rebuild-formal'] == dict(create_calls=31, resize_calls=30)

index = [dict(file=name, bytes=len(value), sha256=hashlib.sha256(value).hexdigest())
         for name, value in sorted(payload.items())]
assert sum(r['bytes'] for r in index) < 128*1024**2
archive = output/'observations.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as destination:
    for name, value in sorted(payload.items()):
        info = zipfile.ZipInfo(name)
        info.compress_type = zipfile.ZIP_DEFLATED
        destination.writestr(info, value, compresslevel=9)
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    for row in index:
        assert hashlib.sha256(saved.read(row['file'])).hexdigest() == row['sha256']

def save(name, value):
    (output/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

save('measurements.json', records)
save('archive-index.json', index)
verification = dict(date='2026-11-11', product_commit='e3f0d03',
    environment=dict(gpu='RTX 4070 SUPER', driver='621.14', ram_gib=64, python='3.13.3'),
    formal_cases=list(formal_names), formal_case_count=len(formal),
    formal_processed_frames=sum(r['total_frames'] for r in formal),
    all_formal_processing_and_exit_passed=True,
    all_case_source_and_runtime_manifests_unchanged=True,
    all_formal_closes_retired_workers_and_unlinked_shared_frames=all(
        c.get('returned') and c.get('worker_absent_in_all_post_close_samples')
        and c.get('shared_frames_unlinked')==2 for r in formal for c in r['closes']),
    native_feature_counts=counts,
    long_term_memory_plateau_verified=False,
    observed_idle_plateau_passed=False,
    idle_plateau_limits=dict(max_absolute_mib_per_minute=.25,max_window_delta_mib=16),
    cpu_control_gpu_queries=False,
    upstream_application_binaries_executed=False,
    no_driver_global_settings_or_product_implementation_changed=True,
    diagnostic_safety_checks=dict(logical_boundary_checks=6,real_guarded_pilot_passed=
        by_name['nr-rebuild-guarded-pilot']['result']['processing_and_exit_passed']),
    failed_pilot=dict(case='nr-rebuild-pilot',native_close_did_not_return=True,
        supervisor_timeout_seconds=90,required_own_job_cleanup=True,
        included_in_formal_acceptance=False,root_cause_stack_not_captured=True),
    limitations=['Small synthetic frames and finite three-by-60-second windows; no overnight or long-video acceptance',
        'CPU idle controls do not query GPU status; GPU feature cases use external WDDM counters',
        'One formal VSR system-commit close window rose while owned processes retired; preserved, not discarded',
        'A separate VSR recheck observed a system-commit drop, but background allocation is not causally attributed',
        'GPU counter disappearance alone does not certify every driver/kernel allocation was released',
        'Parameter changes and native resize were measured; upstream application releases were not run'],
    measured_probe_sources=sources,
    artifacts=[dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
        for p in (archive,output/'measurements.json',output/'archive-index.json')])
save('verification.json', verification)
print(json.dumps(dict(output=str(output),cases=len(records),formal=len(formal),
    formal_frames=verification['formal_processed_frames'],archive_bytes=archive.stat().st_size,
    raw_bytes=sum(r['bytes'] for r in index),verified_files=len(index)),ensure_ascii=False))
